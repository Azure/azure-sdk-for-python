# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------

VERSION = "5.2.0b5"
DEFAULT_API_VERSION = "2022-04-01-preview"
VERSIONS_SUPPORTED = ["v3.0", "v3.1", "2022-04-01-preview"]

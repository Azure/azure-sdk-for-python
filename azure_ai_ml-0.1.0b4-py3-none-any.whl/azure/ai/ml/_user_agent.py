# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azure.ai.ml._version import VERSION

USER_AGENT = "{}/{}".format("azure-ai-ml", VERSION)

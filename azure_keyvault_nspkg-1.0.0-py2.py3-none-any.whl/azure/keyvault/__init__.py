# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
# pylint:disable=missing-docstring
__path__ = __import__("pkgutil").extend_path(__path__, __name__)  # type: ignore

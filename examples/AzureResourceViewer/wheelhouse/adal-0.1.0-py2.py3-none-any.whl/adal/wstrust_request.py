﻿#-------------------------------------------------------------------------
#
# Copyright Microsoft Open Technologies, Inc.
#
# All Rights Reserved
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http: *www.apache.org/licenses/LICENSE-2.0
#
# THIS CODE IS PROVIDED *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS
# OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION
# ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A
# PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
#
# See the Apache License, Version 2.0 for the specific language
# governing permissions and limitations under the License.
#
#--------------------------------------------------------------------------

import requests
import uuid
import time

from datetime import datetime, timedelta

from . import log
from . import util
from . import wstrust_response

class WSTrustRequest(object):

    def __init__(self, call_context, watrust_endpoint_url, applies_to):
        self._log = log.Logger('WSTrustRequest', call_context['log_context'])
        self._call_context = call_context
        self._wstrust_endpoint_url = watrust_endpoint_url
        self._applies_to = applies_to

    def _build_soap_message_credentials(self, username, password):
        username_token_xml = "<wsse:UsernameToken wsu:Id=\'ADALUsernameToken\'>\
                              <wsse:Username>{0}</wsse:Username>\
                              <wsse:Password>{1}</wsse:Password>\
                              </wsse:UsernameToken>".format(username, password)
        return username_token_xml

    def _build_security_header(self, username, password):

        time_now = datetime.utcnow()
        expire_time = time_now + timedelta(minutes=10)

        time_now_str = time_now.isoformat()[:-3] + 'Z'
        expire_time_str = expire_time.isoformat()[:-3] + 'Z'

        security_header_xml = "<wsse:Security s:mustUnderstand=\'1\' xmlns:wsse=\'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\'>\
                               <wsu:Timestamp wsu:Id=\'_0\'>\
                               <wsu:Created>{0}</wsu:Created>\
                               <wsu:Expires>{1}</wsu:Expires>\
                               </wsu:Timestamp>{2}</wsse:Security>".format(time_now_str, expire_time_str,
                                                                           self._build_soap_message_credentials(username, password))
        return security_header_xml

    def _build_rst(self, username, password):

        message_id = str(uuid.uuid4())
        rst = "<s:Envelope xmlns:s=\'http://www.w3.org/2003/05/soap-envelope\' xmlns:wsa=\'http://www.w3.org/2005/08/addressing\' xmlns:wsu=\'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\'>\
      <s:Header>\
        <wsa:Action s:mustUnderstand=\'1\'>http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue</wsa:Action>\
        <wsa:messageID>urn:uuid:{0}</wsa:messageID>\
        <wsa:ReplyTo>\
          <wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address>\
        </wsa:ReplyTo>\
        <wsa:To s:mustUnderstand=\'1\'>{1}</wsa:To>\
        {2}\
      </s:Header>\
      <s:Body>\
        <wst:RequestSecurityToken xmlns:wst=\'http://docs.oasis-open.org/ws-sx/ws-trust/200512\'>\
          <wsp:AppliesTo xmlns:wsp=\'http://schemas.xmlsoap.org/ws/2004/09/policy\'>\
            <wsa:EndpointReference>\
              <wsa:Address>{3}</wsa:Address>\
            </wsa:EndpointReference>\
          </wsp:AppliesTo>\
          <wst:KeyType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Bearer</wst:KeyType>\
          <wst:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</wst:RequestType>\
        </wst:RequestSecurityToken>\
      </s:Body>\
    </s:Envelope>".format(message_id, self._wstrust_endpoint_url, self._build_security_header(username, password), self._applies_to)

        return rst

    def _handle_rstr(self, body, callback):

        wstrust_resp = wstrust_response.WSTrustResponse(self._call_context, body)
        try:
            wstrust_resp.parse()
            callback(None, wstrust_resp)
        except Exception as exp:
            callback(exp, wstrust_resp)

    def acquire_token(self, username, password, callback):

        rst = self._build_rst(username, password)
        headers = {'headers': {'Content-type':'application/soap+xml; charset=utf-8',
                               'SOAPAction': 'http://docs.oasis-open.org/ws-sx/ws-trust/200512/RST/Issue'},
                   'body': rst}
        options = util.create_request_options(self, headers)
        self._log.debug("Sending RST to: {0}\n{1}".format(self._wstrust_endpoint_url, rst))

        operation = "WS-Trust RST"
        try:
            resp = requests.post(self._wstrust_endpoint_url, headers=options['headers'], data=rst, allow_redirects = True)

            util.log_return_correlation_id(self._log, operation, resp)

            if not util.is_http_success(resp.status_code):
                return_error_string = "{0} request returned http error: {1}".format(operation, resp.status_code)
                error_response = ""
                if resp.text:
                    return_error_string += " and server response: {0}".format(resp.text)
                    try:
                        error_response = resp.json()
                    except:
                        pass

                callback(self._log.create_error(return_error_string), error_response)
                return

            else:
                self._handle_rstr(resp.text, callback)

        except Exception as exp:
            self._log.error("{0} request failed".format(operation), exp)
            callback(exp, None)
            return

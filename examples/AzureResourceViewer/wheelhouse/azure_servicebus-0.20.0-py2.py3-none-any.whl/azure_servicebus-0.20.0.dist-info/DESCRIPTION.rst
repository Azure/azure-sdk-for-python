Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Service Bus Runtime Client Library.



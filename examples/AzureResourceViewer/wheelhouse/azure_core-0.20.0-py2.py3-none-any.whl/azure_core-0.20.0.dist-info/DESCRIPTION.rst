Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Management core.



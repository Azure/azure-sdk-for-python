Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Resource Management Client Library.



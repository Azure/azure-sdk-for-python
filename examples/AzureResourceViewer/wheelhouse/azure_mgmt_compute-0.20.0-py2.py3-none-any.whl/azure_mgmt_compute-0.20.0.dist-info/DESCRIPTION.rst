Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Compute Resource Management Client Library.



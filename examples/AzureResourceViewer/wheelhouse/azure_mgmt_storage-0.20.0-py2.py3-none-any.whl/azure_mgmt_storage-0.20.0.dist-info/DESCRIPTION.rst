Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Storage Resource Management Client Library.



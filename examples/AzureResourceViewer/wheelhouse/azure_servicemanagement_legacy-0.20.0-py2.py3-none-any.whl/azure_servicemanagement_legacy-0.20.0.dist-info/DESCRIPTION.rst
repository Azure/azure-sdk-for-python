Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Service Management Legacy Client Library.



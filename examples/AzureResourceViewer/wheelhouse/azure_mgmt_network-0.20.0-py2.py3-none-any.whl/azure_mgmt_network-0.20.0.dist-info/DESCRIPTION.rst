Microsoft Azure SDK for Python
==============================

This is the Microsoft Azure Network Resource Management Client Library.



# Integration Scenario

This scenario is intended to exercise the various options of the `optional` environment. Check the values present in `pyproject.toml` under `tool.azure-sdk-build.optional`. This is merely the scenario, and none of the test code. Check `test_optional_functionality.py` for the actual test cases.
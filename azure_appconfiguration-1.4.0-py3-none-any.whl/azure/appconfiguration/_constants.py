# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------

FILTER_TIME_WINDOW = u"Microsoft.TimeWindow"

FILTER_PERCENTAGE = u"Microsoft.Percentage"

FILTER_TARGETING = u"Microsoft.Targeting"

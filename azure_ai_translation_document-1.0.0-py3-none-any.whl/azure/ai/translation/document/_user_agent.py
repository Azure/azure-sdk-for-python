# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------

from ._version import VERSION

USER_AGENT = f"ai-translation-document/{VERSION}"

# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
# pylint: disable=unused-import

from ._client import ConfidentialLedgerClient


__all__ = ["ConfidentialLedgerClient"]

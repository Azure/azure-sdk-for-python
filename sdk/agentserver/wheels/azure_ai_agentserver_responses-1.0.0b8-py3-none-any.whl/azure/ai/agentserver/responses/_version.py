# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.
# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

VERSION = "1.0.0b8"

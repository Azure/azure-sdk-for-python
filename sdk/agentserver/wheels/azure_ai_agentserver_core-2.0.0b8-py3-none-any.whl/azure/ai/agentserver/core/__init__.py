# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Azure AI AgentServerHost core framework.

Provides the :class:`AgentServerHost` base class and shared utilities for
building Azure AI Hosted Agent containers.

Public API::

    from azure.ai.agentserver.core import (
        AgentConfig,
        AgentServerHost,
        FoundryAgentRequestContext,
        configure_observability,
        create_error_response,
        detach_context,
        end_span,
        flush_spans,
        get_request_context,
        record_error,
        read_request_id,
        resolve_state_subdir,
        set_current_span,
        trace_stream,
    )
"""

__path__ = __import__("pkgutil").extend_path(__path__, __name__)

from ._base import AgentServerHost
from ._config import AgentConfig, resolve_state_subdir
from ._errors import create_error_response
from ._middleware import InboundRequestLoggingMiddleware
from ._request_context import (
    FoundryAgentRequestContext,
    get_request_context,
    reset_request_context,
    set_request_context,
)
from ._request_id import RequestIdMiddleware, read_request_id
from ._server_version import build_server_version
from ._tracing import (
    configure_observability,
    detach_context,
    end_span,
    flush_spans,
    record_error,
    set_current_span,
    trace_stream,
)
from ._version import VERSION

__all__ = [
    "AgentConfig",
    "AgentServerHost",
    "InboundRequestLoggingMiddleware",
    "FoundryAgentRequestContext",
    "RequestIdMiddleware",
    "build_server_version",
    "configure_observability",
    "create_error_response",
    "detach_context",
    "end_span",
    "flush_spans",
    "get_request_context",
    "record_error",
    "read_request_id",
    "reset_request_context",
    "resolve_state_subdir",
    "set_current_span",
    "set_request_context",
    "trace_stream",
]
__version__ = VERSION

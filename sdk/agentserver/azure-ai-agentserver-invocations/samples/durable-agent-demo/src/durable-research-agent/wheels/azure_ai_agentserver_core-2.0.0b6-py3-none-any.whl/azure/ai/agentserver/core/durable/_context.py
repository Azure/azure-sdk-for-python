# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""TaskContext — the single parameter to a durable task function.

Provides identity, typed input, mutable metadata, cancellation signals,
and the ``suspend()`` method for pausing execution.

Spec 016 (US6/US8) introduces the cancel-cause boolean surface
(``timeout_exceeded``, ``cancel_requested``, ``pending_input_count``,
``is_steered_turn``) and the ``exit_for_recovery()`` graceful-shutdown
shape. The legacy fields ``was_steered`` / ``pending_inputs`` /
``steering_generation`` are removed (FR-019/FR-020/FR-021).
"""

from __future__ import annotations

import asyncio  # pylint: disable=do-not-import-asyncio
from typing import Any, Callable, Generic, Literal, TypeVar

from ._metadata import TaskMetadata
from ._stream import StreamHandler

Input = TypeVar("Input")
Output = TypeVar("Output")

EntryMode = Literal["fresh", "resumed", "recovered"]
"""Why the durable function was entered.

- ``"fresh"`` — First execution. Task was just created or started from pending.
- ``"resumed"`` — Re-entered after suspension. On developer-initiated resume
  (via ``.run()``), ``ctx.input`` contains the new input. On platform-initiated
  resume (via ``/tasks/{task_id}/resume``), ``ctx.input`` contains the task's
  persisted input. Also used when a steering input drains from the queue —
  check ``ctx.is_steered_turn`` to distinguish steering re-entry from normal
  resume.
- ``"recovered"`` — Re-entered after stale task detection. The previous execution
  crashed or timed out. ``ctx.input`` contains the task's persisted input.
  If a steerable task crashed mid-drain, ``ctx.is_steered_turn`` will be
  ``True``.
"""


class _Suspended:
    """Internal sentinel for suspended tasks. See ``Suspended`` in ``_run.py``."""

    __slots__ = ("reason", "output")

    def __init__(
        self,
        reason: str | None = None,
        output: Any | None = None,
    ) -> None:
        self.reason = reason
        self.output = output


class _ExitForRecovery:
    """Spec 016 FR-027 (US8): internal sentinel returned by
    :meth:`TaskContext.exit_for_recovery` to signal the framework to
    flush metadata, release the lease, and leave the stored status
    as ``in_progress``.
    """

    __slots__ = ()


class TaskContext(Generic[Input]):  # pylint: disable=too-many-instance-attributes
    """The single parameter to a durable task function.

    Provides access to the task's identity, typed input, mutable metadata
    for progress tracking, cancellation signals (with cause booleans),
    and the ability to suspend or exit-for-recovery.

    :param task_id: Unique task identifier.
    :type task_id: str
    :param input: Typed, validated input value.
    :type input: Input
    :param metadata: Mutable progress metadata.
    :type metadata: TaskMetadata
    :param retry_attempt: Durable retry attempt counter. Survives crashes;
        increments only on failure-retries, never on crash recovery.
    :type retry_attempt: int
    :param recovery_count: Crash-recovery counter. Increments each time the
        framework re-enters this task after a lease loss or stale detection.
    :type recovery_count: int
    :param cancel: Request-level cancellation event. The framework sets
        this from multiple causes; observe ``timeout_exceeded``,
        ``cancel_requested``, ``pending_input_count`` to disambiguate.
    :type cancel: asyncio.Event
    :param shutdown: Container-level shutdown event. Precondition for
        :meth:`exit_for_recovery`.
    :type shutdown: asyncio.Event
    """

    __slots__ = (
        "task_id",
        "_session_id",
        "input",
        "metadata",
        "retry_attempt",
        "recovery_count",
        "cancel",
        "shutdown",
        "_suspend_callback",
        "_stream_handler",
        "entry_mode",
        # Spec 016 FR-016..FR-021 (US6) public cancel-cause / steering surface.
        "timeout_exceeded",
        "cancel_requested",
        "is_steered_turn",
        # Internal callable for the live pending_input_count property
        # (FR-019). The framework sets this when constructing the
        # TaskContext; the property reads it on each access so the
        # count reflects the current backlog including inputs queued
        # mid-handler.
        "_pending_count_provider",
    )

    def __init__(
        self,
        *,
        task_id: str,
        session_id: str,
        input: Input,  # noqa: A002 — mirrors the spec naming
        metadata: TaskMetadata,
        retry_attempt: int = 0,
        recovery_count: int = 0,
        cancel: asyncio.Event | None = None,
        shutdown: asyncio.Event | None = None,
        stream_handler: StreamHandler | None = None,
        entry_mode: EntryMode = "fresh",
        is_steered_turn: bool = False,
        pending_count_provider: Callable[[], int] | None = None,
    ) -> None:
        self.task_id = task_id
        self._session_id = session_id
        self.input = input
        self.metadata = metadata
        self.retry_attempt = retry_attempt
        self.recovery_count = recovery_count
        self.cancel = cancel or asyncio.Event()
        self.shutdown = shutdown or asyncio.Event()
        self._suspend_callback: Any = None
        self._stream_handler: StreamHandler | None = stream_handler
        self.entry_mode: EntryMode = entry_mode
        # Spec 016 FR-016..FR-021: public surface fields. Defaults are
        # framework-controlled at construction; framework setters update
        # them in place. No public setters.
        self.timeout_exceeded: bool = False
        self.cancel_requested: bool = False
        self.is_steered_turn: bool = is_steered_turn
        self._pending_count_provider = pending_count_provider

    @property
    def pending_input_count(self) -> int:
        """Spec 016 FR-019 (US6): live count of queued steering inputs.

        Reflects the current backlog including inputs queued mid-handler.
        Reads as ``0`` for non-steerable tasks (where the provider
        returns 0). Replaces the legacy ``ctx.pending_inputs: Sequence[Any]``
        snapshot.

        :return: Number of queued steering inputs.
        :rtype: int
        """
        if self._pending_count_provider is None:
            return 0
        try:
            return int(self._pending_count_provider())
        except Exception:  # pylint: disable=broad-exception-caught  # noqa: BLE001
            return 0

    async def suspend(
        self,
        *,
        reason: str | None = None,
        output: Any | None = None,
    ) -> Any:
        """Suspend the task, releasing the lease and persisting state.

        Must be used as ``return await ctx.suspend(...)``. The framework
        interprets the returned sentinel to transition the task to
        ``suspended`` status.

        :keyword reason: Human-readable suspension reason.
        :paramtype reason: str | None
        :keyword output: Optional output snapshot for observers.
        :paramtype output: Any | None
        :return: A ``Suspended`` sentinel that the framework interprets.
        :rtype: Suspended
        """
        from ._run import Suspended  # pylint: disable=import-outside-toplevel

        return Suspended(reason=reason, output=output)

    async def stream(self, item: Any) -> None:
        """Emit a streaming item to observers iterating this task's output.

        When a :class:`~azure.ai.agentserver.core.durable.StreamHandler`
        is configured, the item is routed through ``handler.put(item)``.
        Otherwise the call is a no-op.

        :param item: The value to stream.
        :type item: Any
        """
        if self._stream_handler is not None:
            await self._stream_handler.put(item)

    async def exit_for_recovery(self) -> Any:
        """Spec 016 FR-027 (US8): graceful-shutdown shape.

        Callable ONLY when ``ctx.shutdown.is_set() == True``. Calling it
        outside shutdown raises ``RuntimeError`` at the call site
        (visible in user-code tracebacks; the task ends in ``failed``).

        When called during shutdown, the framework:

        1. Flushes ``ctx.metadata`` (FR-015 auto-flush invariant).
        2. Releases the lease on the persisted record.
        3. Leaves the stored ``status`` as ``in_progress`` (NOT
           transitions to ``suspended``).
        4. Signals in-process awaiters with the standard cooperative-
           cancel ``TaskCancelled`` result.
        5. Preserves any queued steering inputs in the persisted state
           (FR-028).

        The recovery scan on the next process startup re-enters the
        handler with ``ctx.entry_mode == "recovered"``.

        Use as ``return await ctx.exit_for_recovery()``.

        :return: The :class:`_ExitForRecovery` sentinel.
        :rtype: Any
        :raises RuntimeError: If called outside ``ctx.shutdown.is_set() == True``.
        """
        if not self.shutdown.is_set():
            raise RuntimeError(
                "ctx.exit_for_recovery() may only be called when "
                "ctx.shutdown.is_set() is true. The misuse-as-failed "
                "semantic exists so operator logs surface accidental "
                "calls loudly (spec 016 FR-027)."
            )
        return _ExitForRecovery()

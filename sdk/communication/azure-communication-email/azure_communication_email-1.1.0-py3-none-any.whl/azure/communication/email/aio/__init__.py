from ._email_client_async import EmailClient

__all__ = [
    "EmailClient",
]

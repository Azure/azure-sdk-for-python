from pyspark import SparkFiles
import os

def greeting(s):
    return f'Hello, {s}!'

def from_file():
    f = open(SparkFiles.get('file_out.txt'), 'r')
    return f.read()

def list_dir():
    dir = SparkFiles.getRootDirectory()
    #list files in dir
    dir_list = os.listdir(dir)
    #print(dir_list)
    return ','.join(dir_list)

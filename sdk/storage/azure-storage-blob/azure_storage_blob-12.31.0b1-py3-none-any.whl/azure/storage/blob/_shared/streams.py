# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------

import math
import sys
from enum import auto, Enum, IntFlag
from io import BytesIO, IOBase, UnsupportedOperation, SEEK_SET
from typing import IO, Iterator, Optional

from .validation import calculate_crc64

DEFAULT_MESSAGE_VERSION = 1
DEFAULT_SEGMENT_SIZE = 4 * 1024 * 1024


class StructuredMessageConstants:
    V1_HEADER_LENGTH = 13
    V1_SEGMENT_HEADER_LENGTH = 10
    CRC64_LENGTH = 8


class StructuredMessageProperties(IntFlag):
    NONE = 0
    CRC64 = auto()


class SMRegion(Enum):
    MESSAGE_HEADER = 1
    SEGMENT_HEADER = 2
    SEGMENT_CONTENT = 3
    SEGMENT_FOOTER = 4
    MESSAGE_FOOTER = 5


def generate_message_header(version: int, size: int, flags: StructuredMessageProperties, num_segments: int) -> bytes:
    return (
        version.to_bytes(1, "little")
        + size.to_bytes(8, "little")
        + flags.to_bytes(2, "little")
        + num_segments.to_bytes(2, "little")
    )


def generate_segment_header(number: int, size: int) -> bytes:
    return number.to_bytes(2, "little") + size.to_bytes(8, "little")


def parse_message_header(data: bytes, expected_message_length: int) -> tuple[int, StructuredMessageProperties, int]:
    version = data[0]
    if version != 1:
        raise ValueError(f"The structured message version is not supported: {version}")
    message_length = int.from_bytes(data[1:9], "little")
    if message_length != expected_message_length:
        raise ValueError(
            f"Structured message length {message_length} " f"did not match content length {expected_message_length}"
        )
    flags = StructuredMessageProperties(int.from_bytes(data[9:11], "little"))
    num_segments = int.from_bytes(data[11:13], "little")
    return version, flags, num_segments


def parse_segment_header(data: bytes, expected_segment_number: int) -> tuple[int, int]:
    segment_number = int.from_bytes(data[0:2], "little")
    if segment_number != expected_segment_number:
        raise ValueError(f"Structured message segment number invalid or out of order {segment_number}")
    segment_content_length = int.from_bytes(data[2:10], "little")
    return segment_number, segment_content_length


class StructuredMessageEncodeStream(IOBase):  # pylint: disable=too-many-instance-attributes
    message_version: int
    content_length: int
    message_length: int
    flags: StructuredMessageProperties

    _inner_stream: IO[bytes]
    _segment_size: int
    _num_segments: int

    _initial_content_position: Optional[int]
    """Initial position of the inner stream, None if it did not implement tell()"""
    _content_offset: int
    _current_segment_number: int
    _current_region: SMRegion
    _current_region_length: int
    _current_region_offset: int

    _message_crc64: int
    _segment_crc64s: dict[int, int]

    def __init__(
        self,
        inner_stream: IO[bytes],
        content_length: int,
        flags: StructuredMessageProperties,
        *,
        segment_size: int = DEFAULT_SEGMENT_SIZE,
    ) -> None:
        if segment_size < 1:
            raise ValueError("Segment size must be greater than 0.")

        self.message_version = DEFAULT_MESSAGE_VERSION
        self.content_length = content_length
        self.flags = flags

        self._inner_stream = inner_stream
        self._segment_size = segment_size
        self._num_segments = math.ceil(self.content_length / self._segment_size) or 1

        self.message_length = self._calculate_message_length()

        self._content_offset = 0
        self._current_segment_number = 0  # Will be incremented before first segment
        self._current_region = SMRegion.MESSAGE_HEADER
        self._current_region_length = self._message_header_length
        self._current_region_offset = 0

        self._message_crc64 = 0
        self._segment_crc64s = {}

        # Attempt to get starting position of inner stream. If we can't, this stream will not be seekable
        try:
            self._initial_content_position = self._inner_stream.tell()
        except (AttributeError, UnsupportedOperation, OSError):
            self._initial_content_position = None
        super().__init__()

    @property
    def _message_header_length(self) -> int:
        return StructuredMessageConstants.V1_HEADER_LENGTH

    @property
    def _segment_header_length(self) -> int:
        return StructuredMessageConstants.V1_SEGMENT_HEADER_LENGTH

    @property
    def _segment_footer_length(self) -> int:
        return StructuredMessageConstants.CRC64_LENGTH if StructuredMessageProperties.CRC64 in self.flags else 0

    @property
    def _message_footer_length(self) -> int:
        return StructuredMessageConstants.CRC64_LENGTH if StructuredMessageProperties.CRC64 in self.flags else 0

    def _update_current_region_length(self) -> None:
        if self._current_region == SMRegion.MESSAGE_HEADER:
            self._current_region_length = self._message_header_length
        elif self._current_region == SMRegion.SEGMENT_HEADER:
            self._current_region_length = self._segment_header_length
        elif self._current_region == SMRegion.SEGMENT_CONTENT:
            # Last segment size is remaining content
            if self._current_segment_number == self._num_segments:
                self._current_region_length = self.content_length - (
                    (self._current_segment_number - 1) * self._segment_size
                )
            else:
                self._current_region_length = self._segment_size
        elif self._current_region == SMRegion.SEGMENT_FOOTER:
            self._current_region_length = self._segment_footer_length
        elif self._current_region == SMRegion.MESSAGE_FOOTER:
            self._current_region_length = self._message_footer_length
        else:
            raise ValueError(f"Invalid SMRegion {self._current_region}")

    def __len__(self):
        return self.message_length

    @property
    def closed(self) -> bool:
        return self._inner_stream.closed

    def close(self) -> None:
        # Do not close the inner stream or this stream.
        # The inner stream is caller-owned and must survive for retries.
        # This stream may be re-read after a seek(0) on retry.
        pass

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        try:
            # Only seekable if the inner stream is and we could get its initial position
            return self._inner_stream.seekable() and self._initial_content_position is not None
        except (AttributeError, UnsupportedOperation, OSError):
            return False

    def tell(self) -> int:
        if self._current_region == SMRegion.MESSAGE_HEADER:
            return self._current_region_offset
        if self._current_region == SMRegion.SEGMENT_HEADER:
            return (
                self._message_header_length
                + self._content_offset
                + (self._current_segment_number - 1) * (self._segment_header_length + self._segment_footer_length)
                + self._current_region_offset
            )
        if self._current_region == SMRegion.SEGMENT_CONTENT:
            return (
                self._message_header_length
                + self._content_offset
                + (self._current_segment_number - 1) * (self._segment_header_length + self._segment_footer_length)
                + self._segment_header_length
            )
        if self._current_region == SMRegion.SEGMENT_FOOTER:
            return (
                self._message_header_length
                + self._content_offset
                + (self._current_segment_number - 1) * (self._segment_header_length + self._segment_footer_length)
                + self._segment_header_length
                + self._current_region_offset
            )
        if self._current_region == SMRegion.MESSAGE_FOOTER:
            return (
                self._message_header_length
                + self._content_offset
                + self._current_segment_number * (self._segment_header_length + self._segment_footer_length)
                + self._current_region_offset
            )

        raise ValueError(f"Invalid SMRegion {self._current_region}")

    def seek(self, offset: int, whence: int = SEEK_SET) -> int:
        if not self.seekable():
            raise UnsupportedOperation("Inner stream is not seekable.")

        if whence != SEEK_SET:
            raise UnsupportedOperation("This stream only supports SEEK_SET.")

        if offset != 0:
            raise UnsupportedOperation("This stream only supports seeking to position 0.")

        # Reset to initial state
        self._content_offset = 0
        self._current_segment_number = 0
        self._current_region = SMRegion.MESSAGE_HEADER
        self._current_region_length = self._message_header_length
        self._current_region_offset = 0
        self._message_crc64 = 0
        self._segment_crc64s = {}

        self._inner_stream.seek(self._initial_content_position or 0)
        return 0

    def read(self, size: int = -1) -> bytes:
        if self.closed:  # pylint: disable=using-constant-test
            raise ValueError("Stream is closed")

        if size == 0:
            return b""
        if size < 0:
            size = sys.maxsize

        count = 0
        output = BytesIO()

        while count < size and self.tell() < self.message_length:
            remaining = size - count
            if self._current_region in (
                SMRegion.MESSAGE_HEADER,
                SMRegion.SEGMENT_HEADER,
                SMRegion.SEGMENT_FOOTER,
                SMRegion.MESSAGE_FOOTER,
            ):
                count += self._read_metadata_region(self._current_region, remaining, output)
            elif self._current_region == SMRegion.SEGMENT_CONTENT:
                count += self._read_content(remaining, output)
            else:
                raise ValueError(f"Invalid SMRegion {self._current_region}")

        return output.getvalue()

    def _calculate_message_length(self) -> int:
        length = self._message_header_length
        length += (self._segment_header_length + self._segment_footer_length) * self._num_segments
        length += self.content_length
        length += self._message_footer_length
        return length

    def _get_metadata_region(self, region: SMRegion) -> bytes:
        if region == SMRegion.MESSAGE_HEADER:
            return generate_message_header(
                self.message_version,
                self.message_length,
                self.flags,
                self._num_segments,
            )

        if region == SMRegion.SEGMENT_HEADER:
            segment_size = min(self._segment_size, self.content_length - self._content_offset)
            return generate_segment_header(self._current_segment_number, segment_size)

        if region == SMRegion.SEGMENT_FOOTER:
            if StructuredMessageProperties.CRC64 in self.flags:
                return self._segment_crc64s[self._current_segment_number].to_bytes(
                    StructuredMessageConstants.CRC64_LENGTH, "little"
                )
            return b""

        if region == SMRegion.MESSAGE_FOOTER:
            if StructuredMessageProperties.CRC64 in self.flags:
                return self._message_crc64.to_bytes(StructuredMessageConstants.CRC64_LENGTH, "little")
            return b""

        raise ValueError(f"Invalid metadata SMRegion {self._current_region}")

    def _advance_region(self, current: SMRegion):
        self._current_region_offset = 0

        if current == SMRegion.MESSAGE_HEADER:
            self._current_region = SMRegion.SEGMENT_HEADER
            self._increment_current_segment()
        elif current == SMRegion.SEGMENT_HEADER:
            self._current_region = SMRegion.SEGMENT_CONTENT
        elif current == SMRegion.SEGMENT_CONTENT:
            self._current_region = SMRegion.SEGMENT_FOOTER
        elif current == SMRegion.SEGMENT_FOOTER:
            # If we're at the end of the content
            if self._content_offset == self.content_length:
                self._current_region = SMRegion.MESSAGE_FOOTER
            else:
                self._current_region = SMRegion.SEGMENT_HEADER
                self._increment_current_segment()
        else:
            raise ValueError(f"Invalid SMRegion {self._current_region}")

        self._update_current_region_length()

    def _read_metadata_region(self, region: SMRegion, size: int, output: BytesIO) -> int:
        metadata = self._get_metadata_region(region)

        read_size = min(size, self._current_region_length - self._current_region_offset)
        content = metadata[self._current_region_offset : self._current_region_offset + read_size]
        output.write(content)

        self._current_region_offset += read_size
        if (
            self._current_region_offset == self._current_region_length
            and self._current_region != SMRegion.MESSAGE_FOOTER
        ):
            self._advance_region(region)

        return read_size

    def _read_content(self, size: int, output: BytesIO) -> int:
        read_size = min(size, self._current_region_length - self._current_region_offset)

        content = self._inner_stream.read(read_size)
        if len(content) != read_size:
            raise ValueError("Content ended early when encoding structured message.")
        output.write(content)

        if StructuredMessageProperties.CRC64 in self.flags:
            self._segment_crc64s[self._current_segment_number] = calculate_crc64(
                content, self._segment_crc64s[self._current_segment_number]
            )
            self._message_crc64 = calculate_crc64(content, self._message_crc64)

        self._content_offset += read_size
        self._current_region_offset += read_size
        if self._current_region_offset == self._current_region_length:
            self._advance_region(SMRegion.SEGMENT_CONTENT)

        return read_size

    def _increment_current_segment(self):
        self._current_segment_number += 1
        if StructuredMessageProperties.CRC64 in self.flags:
            # If seek was used, we may already have this segment's CRC (could be partial), otherwise initialize to 0
            self._segment_crc64s.setdefault(self._current_segment_number, 0)


class StructuredMessageDecoder(IOBase):  # pylint: disable=too-many-instance-attributes

    message_version: int
    """The version of the structured message."""
    message_length: int
    """The total length of the structured message."""
    flags: StructuredMessageProperties
    """The properties included in the structured message."""
    num_segments: int
    """The number of message segments."""

    _inner_iterator: Iterator[bytes]
    _buffer: bytes
    _message_offset: int
    _message_crc64: int
    _segment_number: int
    _segment_crc64: int
    _segment_content_length: int
    _segment_content_offset: int
    _block_size: int

    def __init__(
        self,
        inner_iterator: Iterator[bytes],
        content_length: int,
        *,
        block_size: int = 4096,
    ) -> None:
        self.message_length = content_length
        # The stream should be at least long enough to hold minimum header length
        if self.message_length < StructuredMessageConstants.V1_HEADER_LENGTH:
            raise ValueError("Content not long enough to contain a valid message header.")

        self._inner_iterator = inner_iterator
        self._buffer = b""
        self._message_offset = 0
        self._message_crc64 = 0

        self._segment_number = 0
        self._segment_crc64 = 0
        self._segment_content_length = 0
        self._segment_content_offset = 0
        self._block_size = block_size
        super().__init__()

    @property
    def content_length(self) -> int:
        return self.message_length

    @property
    def _segment_header_length(self) -> int:
        return StructuredMessageConstants.V1_SEGMENT_HEADER_LENGTH

    @property
    def _segment_footer_length(self) -> int:
        return StructuredMessageConstants.CRC64_LENGTH if StructuredMessageProperties.CRC64 in self.flags else 0

    @property
    def _message_footer_length(self) -> int:
        return StructuredMessageConstants.CRC64_LENGTH if StructuredMessageProperties.CRC64 in self.flags else 0

    @property
    def _end_of_segment_content(self) -> bool:
        return self._segment_content_offset == self._segment_content_length

    def readable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    def __iter__(self):
        return self

    def __next__(self) -> bytes:
        data = self.read(self._block_size)
        if not data:
            raise StopIteration
        return data

    def read(self, size: int = -1) -> bytes:
        if self.closed:  # pylint: disable=using-constant-test
            raise ValueError("Stream is closed")

        if size == 0 or self._message_offset >= self.message_length:
            return b""
        if size < 0:
            size = sys.maxsize

        # On the first read, read message header and first segment header
        if self._message_offset == 0:
            self._read_message_header()
            self._read_segment_header()

            # Special case for 0 length content
            if self._end_of_segment_content:
                self._read_segment_footer()
                if self.num_segments > 1:
                    raise ValueError("First message segment was empty but more segments were detected.")
                self._read_message_footer()
                return b""

        count = 0
        content = BytesIO()
        while count < size and not (self._end_of_segment_content and self._message_offset == self.message_length):
            if self._end_of_segment_content:
                self._read_segment_header()

            segment_remaining = self._segment_content_length - self._segment_content_offset
            read_size = min(segment_remaining, size - count)

            segment_content = self._read_from_inner(read_size)
            content.write(segment_content)

            # Update the running CRC64 for the segment and message
            if StructuredMessageProperties.CRC64 in self.flags:
                self._segment_crc64 = calculate_crc64(segment_content, self._segment_crc64)
                self._message_crc64 = calculate_crc64(segment_content, self._message_crc64)

            self._segment_content_offset += read_size
            self._message_offset += read_size
            count += read_size

            if self._end_of_segment_content:
                self._read_segment_footer()
                # If we are on the last segment, also read the message footer
                if self._segment_number == self.num_segments:
                    self._read_message_footer()

        # One final check to ensure if we think we've reached the end of the stream
        # that the current segment number matches the total.
        if self._message_offset == self.message_length and self._segment_number != self.num_segments:
            raise ValueError("Invalid structured message data detected.")

        return content.getvalue()

    def _read_from_inner(self, size: int) -> bytes:
        while len(self._buffer) < size:
            try:
                chunk = next(self._inner_iterator)
            except StopIteration:
                break
            self._buffer += chunk

        if len(self._buffer) < size:
            raise ValueError("Invalid structured message data detected. Stream content incomplete.")

        data = self._buffer[:size]
        self._buffer = self._buffer[size:]
        return data

    def _read_message_header(self) -> None:
        header_data = self._read_from_inner(StructuredMessageConstants.V1_HEADER_LENGTH)
        self.message_version, self.flags, self.num_segments = parse_message_header(header_data, self.message_length)
        self._message_offset += StructuredMessageConstants.V1_HEADER_LENGTH

    def _read_message_footer(self) -> None:
        # Sanity check: There should only be self._message_footer_length (could be 0) bytes left to consume.
        # If not, it is likely the message header contained incorrect info.
        if self.message_length - self._message_offset != self._message_footer_length:
            raise ValueError("Invalid structured message data detected.")

        if StructuredMessageProperties.CRC64 in self.flags:
            message_crc = self._read_from_inner(StructuredMessageConstants.CRC64_LENGTH)

            if self._message_crc64 != int.from_bytes(message_crc, "little"):
                raise ValueError(
                    "CRC64 mismatch detected in message trailer. All data read should be considered invalid."
                )

        self._message_offset += self._message_footer_length

    def _read_segment_header(self) -> None:
        header_data = self._read_from_inner(self._segment_header_length)
        self._segment_number, self._segment_content_length = parse_segment_header(header_data, self._segment_number + 1)
        self._message_offset += self._segment_header_length

        self._segment_content_offset = 0
        self._segment_crc64 = 0

    def _read_segment_footer(self) -> None:
        if StructuredMessageProperties.CRC64 in self.flags:
            segment_crc = self._read_from_inner(StructuredMessageConstants.CRC64_LENGTH)

            if self._segment_crc64 != int.from_bytes(segment_crc, "little"):
                raise ValueError(
                    f"CRC64 mismatch detected in segment {self._segment_number}. "
                    f"All data read should be considered invalid."
                )

        self._message_offset += self._segment_footer_length

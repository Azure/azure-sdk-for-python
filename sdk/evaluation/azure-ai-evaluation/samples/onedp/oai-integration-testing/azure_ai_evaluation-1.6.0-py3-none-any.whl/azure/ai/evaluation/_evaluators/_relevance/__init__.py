# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._relevance import RelevanceEvaluator

__all__ = [
    "RelevanceEvaluator",
]

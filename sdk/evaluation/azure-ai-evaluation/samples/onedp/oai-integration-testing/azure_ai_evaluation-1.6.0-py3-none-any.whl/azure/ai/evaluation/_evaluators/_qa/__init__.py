# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._qa import QAEvaluator

__all__ = [
    "QAEvaluator",
]

# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Invocation protocol host for Azure AI Hosted Agents.

Provides the invocation protocol endpoints and handler decorators
as a :class:`~azure.ai.agentserver.core.AgentServerHost` subclass.
"""
import contextvars
import inspect
import logging
import re
import threading
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable  # pylint: disable=import-error
from typing import Any, Optional

from opentelemetry import baggage as _otel_baggage, context as _otel_context, trace
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse
from starlette.routing import Route

from azure.ai.agentserver.core import (  # pylint: disable=no-name-in-module
    AgentServerHost,
    FoundryAgentRequestContext,
    create_error_response,
    reset_request_context,
    set_request_context,
)
from azure.ai.agentserver.core._platform_headers import (  # pylint: disable=import-error,no-name-in-module
    ERROR_DETAIL,
    ERROR_SOURCE,
    FOUNDRY_CALL_ID,
    MAX_ERROR_DETAIL_LENGTH,
    PLATFORM_ERROR_TAG,
    USER_ID,
)

from ._constants import InvocationConstants
from ._invocation_ws import _WSHandlerMixin

logger = logging.getLogger("azure.ai.agentserver")

# ---------------------------------------------------------------------------
# Internal error-source classification
# ---------------------------------------------------------------------------

_ERROR_SOURCE_UPSTREAM: str = "upstream"
_ERROR_SOURCE_PLATFORM: str = "platform"


def _apply_error_source_headers(
    headers: dict[str, str],
    error_source: str,
    error_detail: Optional[str] = None,
) -> dict[str, str]:
    """Return a new dict with error source classification headers merged in.

    :param headers: Base headers to merge into.
    :type headers: dict[str, str]
    :param error_source: The error source value (user/platform/upstream).
    :type error_source: str
    :param error_detail: Optional detail string for platform errors.
    :type error_detail: str or None
    :return: A new dict containing the original headers plus error source headers.
    :rtype: dict[str, str]
    """
    merged = {**headers, ERROR_SOURCE: error_source}
    if error_detail:
        merged[ERROR_DETAIL] = error_detail
    return merged


def _classify_error(exc: BaseException) -> tuple[str, Optional[str]]:
    """Classify an exception: platform-tagged → (platform, detail), else → (upstream, None).

    :param exc: The exception to classify.
    :type exc: BaseException
    :return: A tuple of (error_source, error_detail).
    :rtype: tuple[str, str or None]
    """
    if getattr(exc, PLATFORM_ERROR_TAG, False) is True:
        detail = f"{type(exc).__name__}: {exc}"
        if len(detail) > MAX_ERROR_DETAIL_LENGTH:
            suffix = "...[truncated]"
            detail = detail[: MAX_ERROR_DETAIL_LENGTH - len(suffix)] + suffix
        return _ERROR_SOURCE_PLATFORM, detail
    return _ERROR_SOURCE_UPSTREAM, None

# Maximum length and allowed characters for user-provided IDs (defense in depth).
_MAX_ID_LENGTH = 256
_VALID_ID_RE = re.compile(r"^[a-zA-Z0-9\-_.:]+$")


# Context variables for structured logging — concurrency-safe alternative to logger filters.
_invocation_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("invocation_id", default="")
_session_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("session_id", default="")


class _InvocationLogFilter(logging.Filter):
    """Attach invocation and session IDs to every log record from context vars.

    Reads from ``contextvars`` rather than instance state, so a single
    filter instance can be installed once on the logger (not per-request).
    """

    def filter(self, record: logging.LogRecord) -> bool:
        record.invocation_id = _invocation_id_var.get("")  # type: ignore[attr-defined]
        record.session_id = _session_id_var.get("")  # type: ignore[attr-defined]
        return True


# Install once on first request — no per-request add/remove needed.
_log_filter_lock = threading.Lock()
_log_filter_installed = False


def _ensure_log_filter() -> None:
    """Install the log filter on first use (lazy, thread-safe)."""
    global _log_filter_installed  # pylint: disable=global-statement
    if _log_filter_installed:
        return
    with _log_filter_lock:
        if _log_filter_installed:
            return
        logger.addFilter(_InvocationLogFilter())
        _log_filter_installed = True


def _sanitize_id(value: str, fallback: str) -> str:
    """Validate a user-provided ID string.

    Returns *value* unchanged when it passes validation, otherwise returns
    *fallback*.  This prevents excessively long or malformed IDs from
    propagating into headers, span attributes, and log messages.

    :param value: The raw ID from a header or query parameter.
    :type value: str
    :param fallback: A safe fallback value (typically a generated UUID).
    :type fallback: str
    :return: The validated ID or the fallback.
    :rtype: str
    """
    if not value or len(value) > _MAX_ID_LENGTH or not _VALID_ID_RE.match(value):
        return fallback
    return value


class InvocationAgentServerHost(_WSHandlerMixin, AgentServerHost):
    """Invocation protocol host for Azure AI Hosted Agents.

    A :class:`~azure.ai.agentserver.core.AgentServerHost` subclass that adds
    the invocation protocol endpoints.  Use the decorator methods to wire
    handler functions to the endpoints.

    The same host object also exposes the ``invocations_ws`` (WebSocket)
    transport at :data:`/invocations_ws` — register a handler with the
    :meth:`ws_handler` decorator.  Multi-protocol agents share a single
    host, session, and process.

    For multi-protocol agents, compose via cooperative inheritance::

        class MyHost(InvocationAgentServerHost, ResponsesAgentServerHost):
            pass

    Usage::

        from azure.ai.agentserver.invocations import InvocationAgentServerHost
        from starlette.websockets import WebSocket

        app = InvocationAgentServerHost()

        @app.invoke_handler                  # POST /invocations
        async def handle(request):
            return JSONResponse({"ok": True})

        @app.ws_handler                      # /invocations_ws
        async def ws(websocket: WebSocket) -> None:
            async for message in websocket.iter_text():
                await websocket.send_text(message)

        app.run()

    :param openapi_spec: Optional OpenAPI spec dict.  When provided, the spec
        is served at ``GET /invocations/docs/openapi.json``.
    :type openapi_spec: Optional[dict[str, Any]]
    """

    _INSTRUMENTATION_SCOPE = "Azure.AI.AgentServer.Invocations"

    def __init__(
        self,
        *,
        openapi_spec: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        self._invoke_fn: Optional[Callable] = None
        self._get_invocation_fn: Optional[Callable] = None
        self._cancel_invocation_fn: Optional[Callable] = None
        self._openapi_spec = openapi_spec

        # Initialise WS handler slots (no parameters — the keep-alive
        # interval lives on ``AgentConfig`` and is wired into Hypercorn
        # by ``AgentServerHost._build_hypercorn_config``).
        self._init_ws_state()

        # Build invocation routes and pass to parent via routes kwarg
        invocation_routes: list[Any] = [
            Route(
                "/invocations/docs/openapi.json",
                self._get_openapi_spec_endpoint,
                methods=["GET"],
                name="get_openapi_spec",
            ),
            Route(
                "/invocations",
                self._create_invocation_endpoint,
                methods=["POST"],
                name="create_invocation",
            ),
            Route(
                "/invocations/{invocation_id}",
                self._get_invocation_endpoint,
                methods=["GET"],
                name="get_invocation",
            ),
            Route(
                "/invocations/{invocation_id}/cancel",
                self._cancel_invocation_endpoint,
                methods=["POST"],
                name="cancel_invocation",
            ),
        ]

        # Merge with any routes from sibling mixins via cooperative init
        existing = list(kwargs.pop("routes", None) or [])
        super().__init__(routes=existing + invocation_routes, **kwargs)

        # --- Invocations startup configuration logging ---
        logger.info(
            "Invocations protocol: openapi_spec_configured=%s",
            self._openapi_spec is not None,
        )

    # ------------------------------------------------------------------
    # Handler decorators
    # ------------------------------------------------------------------

    def invoke_handler(
        self, fn: Callable[[Request], Awaitable[Response]]
    ) -> Callable[[Request], Awaitable[Response]]:
        """Register a function as the invoke handler.

        Usage::

            @invocations.invoke_handler
            async def handle(request: Request) -> Response:
                ...

        :param fn: Async function accepting a Starlette Request and returning a Response.
        :type fn: Callable[[Request], Awaitable[Response]]
        :return: The original function (unmodified).
        :rtype: Callable[[Request], Awaitable[Response]]
        :raises TypeError: If *fn* is not an async function.
        """
        if not inspect.iscoroutinefunction(fn):
            raise TypeError(
                f"invoke_handler expects an async function, got {type(fn).__name__}. "
                "Use 'async def' to define your handler."
            )
        self._invoke_fn = fn
        return fn

    def get_invocation_handler(
        self, fn: Callable[[Request], Awaitable[Response]]
    ) -> Callable[[Request], Awaitable[Response]]:
        """Register a function as the get-invocation handler.

        :param fn: Async function accepting a Starlette Request and returning a Response.
        :type fn: Callable[[Request], Awaitable[Response]]
        :return: The original function (unmodified).
        :rtype: Callable[[Request], Awaitable[Response]]
        :raises TypeError: If *fn* is not an async function.
        """
        if not inspect.iscoroutinefunction(fn):
            raise TypeError(
                f"get_invocation_handler expects an async function, got {type(fn).__name__}. "
                "Use 'async def' to define your handler."
            )
        self._get_invocation_fn = fn
        return fn

    def cancel_invocation_handler(
        self, fn: Callable[[Request], Awaitable[Response]]
    ) -> Callable[[Request], Awaitable[Response]]:
        """Register a function as the cancel-invocation handler.

        :param fn: Async function accepting a Starlette Request and returning a Response.
        :type fn: Callable[[Request], Awaitable[Response]]
        :return: The original function (unmodified).
        :rtype: Callable[[Request], Awaitable[Response]]
        :raises TypeError: If *fn* is not an async function.
        """
        if not inspect.iscoroutinefunction(fn):
            raise TypeError(
                f"cancel_invocation_handler expects an async function, got {type(fn).__name__}. "
                "Use 'async def' to define your handler."
            )
        self._cancel_invocation_fn = fn
        return fn

    # ------------------------------------------------------------------
    # Dispatch methods (internal)
    # ------------------------------------------------------------------

    async def _dispatch_invoke(self, request: Request) -> Response:
        if self._invoke_fn is not None:
            return await self._invoke_fn(request)
        raise NotImplementedError(
            "No invoke handler registered. Use the @invocations.invoke_handler decorator."
        )

    async def _dispatch_get_invocation(self, request: Request) -> Response:
        if self._get_invocation_fn is not None:
            return await self._get_invocation_fn(request)
        return create_error_response(
            "not_found", "get_invocation not implemented",
            status_code=404,
            headers=_apply_error_source_headers({}, _ERROR_SOURCE_UPSTREAM),
        )

    async def _dispatch_cancel_invocation(self, request: Request) -> Response:
        if self._cancel_invocation_fn is not None:
            return await self._cancel_invocation_fn(request)
        return create_error_response(
            "not_found", "cancel_invocation not implemented",
            status_code=404,
            headers=_apply_error_source_headers({}, _ERROR_SOURCE_UPSTREAM),
        )

    def get_openapi_spec(self) -> Optional[dict[str, Any]]:
        """Return the stored OpenAPI spec, or None."""
        return self._openapi_spec

    # ------------------------------------------------------------------
    # Span attribute helper
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Endpoint handlers
    # ------------------------------------------------------------------

    async def _get_openapi_spec_endpoint(self, request: Request) -> Response:  # pylint: disable=unused-argument
        spec = self.get_openapi_spec()
        if spec is None:
            return create_error_response(
                "not_found", "No OpenAPI spec registered",
                status_code=404,
                headers=_apply_error_source_headers({}, _ERROR_SOURCE_UPSTREAM),
            )
        return JSONResponse(spec)

    def _wrap_streaming_response(
        self,
        response: StreamingResponse,
        invocation_id: str,
        session_id: str,
        platform_context: FoundryAgentRequestContext | None = None,
    ) -> StreamingResponse:
        """Wrap streaming body iteration with invocation logging/tracing context.

        :param response: Streaming response to wrap.
        :type response: StreamingResponse
        :param invocation_id: Invocation identifier to stamp in context/logging.
        :type invocation_id: str
        :param session_id: Session identifier to stamp in context/logging.
        :type session_id: str
        :param platform_context: Platform context to re-establish for outbound
            1P calls made during stream iteration (protocol 2.0.0).
        :type platform_context: ~azure.ai.agentserver.core.FoundryAgentRequestContext | None
        :return: The response with a wrapped body_iterator.
        :rtype: StreamingResponse
        """
        original_iterator = response.body_iterator

        async def _wrapped_body() -> AsyncIterator[Any]:
            # Re-establish the invocation context for the streaming task.
            stream_inv_token = _invocation_id_var.set(invocation_id)
            stream_session_token = _session_id_var.set(session_id)
            stream_ctx_token = (
                set_request_context(platform_context) if platform_context is not None else None
            )
            try:
                async for chunk in original_iterator:
                    yield chunk
            except Exception as exc:  # pylint: disable=broad-exception-caught
                logger.error(
                    "Error processing invocation %s: %s",
                    invocation_id, exc, exc_info=True,
                )
                # Record the exception on the current span.
                span = trace.get_current_span()
                if span and span.is_recording():
                    span.set_status(trace.StatusCode.ERROR, str(exc))
                    span.set_attribute("error.type", type(exc).__name__)
                    span.record_exception(exc)
                raise
            finally:
                _invocation_id_var.reset(stream_inv_token)
                _session_id_var.reset(stream_session_token)
                if stream_ctx_token is not None:
                    reset_request_context(stream_ctx_token)

        response.body_iterator = _wrapped_body()
        return response

    async def _create_invocation_endpoint(self, request: Request) -> Response:
        generated_id = str(uuid.uuid4())
        raw_invocation_id = request.headers.get(InvocationConstants.INVOCATION_ID_HEADER) or ""
        invocation_id = _sanitize_id(raw_invocation_id, generated_id)
        request.state.invocation_id = invocation_id

        # Session ID: query param overrides env var / generated UUID
        raw_session_id = (
            request.query_params.get("agent_session_id")
            or self.config.session_id
            or ""
        )
        session_id = _sanitize_id(raw_session_id, str(uuid.uuid4()))
        request.state.session_id = session_id

        # Platform identity headers — expose to handlers
        user_id = request.headers.get(USER_ID, "")
        call_id = request.headers.get(FOUNDRY_CALL_ID, "")
        request.state.user_id = user_id
        request.state.call_id = call_id

        # Incoming baggage and trace context are already attached by
        # BaggageMiddleware and the Starlette OTel instrumentor.
        # Add protocol-specific baggage entries for this invocation.
        ctx = _otel_context.get_current()
        ctx = _otel_baggage.set_baggage(
            "azure.ai.agentserver.invocation_id", invocation_id, context=ctx,
        )
        ctx = _otel_baggage.set_baggage(
            "azure.ai.agentserver.session_id", session_id, context=ctx,
        )
        baggage_token = _otel_context.attach(ctx)

        # Set structured logging context (concurrency-safe via contextvars)
        _ensure_log_filter()
        inv_token = _invocation_id_var.set(invocation_id)
        session_token = _session_id_var.set(session_id)
        # Bind platform context so outbound 1P calls (and handler/tool code) can
        # forward the per-request call ID and user ID (protocol 2.0.0).
        platform_ctx = FoundryAgentRequestContext(
            call_id=call_id or None,
            user_id=user_id or None,
            session_id=session_id,
        )
        ctx_token = set_request_context(platform_ctx)
        try:
            response = await self._dispatch_invoke(request)
            response.headers[InvocationConstants.INVOCATION_ID_HEADER] = invocation_id
            response.headers[InvocationConstants.SESSION_ID_HEADER] = session_id
        except NotImplementedError as exc:
            logger.error("Invocation %s failed: %s", invocation_id, exc)
            return create_error_response(
                "not_implemented",
                str(exc),
                status_code=501,
                headers=_apply_error_source_headers(
                    {
                        InvocationConstants.INVOCATION_ID_HEADER: invocation_id,
                        InvocationConstants.SESSION_ID_HEADER: session_id,
                    },
                    _ERROR_SOURCE_UPSTREAM,
                ),
            )
        except Exception as exc:  # pylint: disable=broad-exception-caught
            error_source, error_detail = _classify_error(exc)
            logger.error("Error processing invocation %s: %s", invocation_id, exc, exc_info=True)
            return create_error_response(
                "internal_error",
                "Internal server error",
                status_code=500,
                headers=_apply_error_source_headers(
                    {
                        InvocationConstants.INVOCATION_ID_HEADER: invocation_id,
                        InvocationConstants.SESSION_ID_HEADER: session_id,
                    },
                    error_source,
                    error_detail,
                ),
            )
        finally:
            # Always reset the request-scope tokens and detach baggage from the
            # calling context here. The streaming wrapper separately resets the
            # tokens it sets for stream iteration.
            _invocation_id_var.reset(inv_token)
            _session_id_var.reset(session_token)
            reset_request_context(ctx_token)
            try:
                _otel_context.detach(baggage_token)
            except ValueError:
                pass

        # Wrap streaming response body so exceptions during iteration are
        # recorded on the current trace span and logged as invocation errors.
        if isinstance(response, StreamingResponse):
            response = self._wrap_streaming_response(
                response, invocation_id, session_id, platform_ctx
            )

        return response

    async def _traced_invocation_endpoint(
        self,
        request: Request,
        span_operation: str,
        dispatch: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        raw_invocation_id = request.path_params["invocation_id"]
        invocation_id = _sanitize_id(raw_invocation_id, raw_invocation_id)
        request.state.invocation_id = invocation_id

        raw_session_id = request.query_params.get("agent_session_id", "")
        session_id = _sanitize_id(raw_session_id, "") if raw_session_id else ""

        _ensure_log_filter()
        inv_token = _invocation_id_var.set(invocation_id)
        session_token = _session_id_var.set(session_id)
        try:
            response = await dispatch(request)
            response.headers[InvocationConstants.INVOCATION_ID_HEADER] = invocation_id
            return response
        except Exception as exc:  # pylint: disable=broad-exception-caught
            error_source, error_detail = _classify_error(exc)
            logger.error("Error in %s %s: %s", span_operation, invocation_id, exc, exc_info=True)
            return create_error_response(
                "internal_error",
                "Internal server error",
                status_code=500,
                headers=_apply_error_source_headers(
                    {InvocationConstants.INVOCATION_ID_HEADER: invocation_id},
                    error_source,
                    error_detail,
                ),
            )
        finally:
            _invocation_id_var.reset(inv_token)
            _session_id_var.reset(session_token)

    async def _get_invocation_endpoint(self, request: Request) -> Response:
        return await self._traced_invocation_endpoint(
            request, "get_invocation", self._dispatch_get_invocation
        )

    async def _cancel_invocation_endpoint(self, request: Request) -> Response:
        return await self._traced_invocation_endpoint(
            request, "cancel_invocation", self._dispatch_cancel_invocation
        )

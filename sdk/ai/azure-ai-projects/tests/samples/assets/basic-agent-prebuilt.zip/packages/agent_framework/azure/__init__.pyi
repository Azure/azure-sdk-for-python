# Copyright (c) Microsoft. All rights reserved.

# Type stubs for the agent_framework.azure lazy-loading namespace.
# Install the relevant packages for full type support.

from agent_framework_azure_ai_search import (
    AzureAISearchContextProvider,
    AzureAISearchSettings,
)
from agent_framework_azure_cosmos import CosmosHistoryProvider
from agent_framework_azurefunctions import AgentFunctionApp
from agent_framework_durabletask import (
    WORKFLOW_ORCHESTRATOR_NAME,
    AgentCallbackContext,
    AgentResponseCallbackProtocol,
    DurableAIAgent,
    DurableAIAgentClient,
    DurableAIAgentOrchestrationContext,
    DurableAIAgentWorker,
    DurableWorkflowClient,
)

__all__ = [
    "WORKFLOW_ORCHESTRATOR_NAME",
    "AgentCallbackContext",
    "AgentFunctionApp",
    "AgentResponseCallbackProtocol",
    "AzureAISearchContextProvider",
    "AzureAISearchSettings",
    "CosmosHistoryProvider",
    "DurableAIAgent",
    "DurableAIAgentClient",
    "DurableAIAgentOrchestrationContext",
    "DurableAIAgentWorker",
    "DurableWorkflowClient",
]

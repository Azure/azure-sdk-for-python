# pylint: disable=line-too-long,useless-suppression
# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
"""Async RLE environment runtime helpers.

These helpers layer a Gymnasium-style ergonomic surface on top of the generated async RLE
operations. Every request is issued through the :class:`~azure.ai.projects.aio.AIProjectClient`
pipeline against the Foundry project endpoint, exactly like the other operation groups.
"""

from __future__ import annotations

import asyncio  # pylint: disable=do-not-import-asyncio
import logging
import time
from typing import (
    Any,
    Callable,
    Dict,
    Mapping,
    Optional,
    Sequence,
    TYPE_CHECKING,
    Union,
)

from websockets.asyncio.client import ClientConnection, connect as websocket_connect
from websockets.exceptions import InvalidMessage, InvalidStatus
from websockets.typing import Subprotocol

try:
    from websockets.exceptions import InvalidProxyStatus as _InvalidProxyStatus
except ImportError:  # websockets 14.0 doesn't define InvalidProxyStatus.
    _InvalidProxyStatus = InvalidStatus  # type: ignore[misc, assignment]

from azure.core.async_paging import AsyncItemPaged, AsyncList
from azure.core.exceptions import AzureError, HttpResponseError
from azure.core.tracing.decorator import distributed_trace
from azure.core.tracing.decorator_async import distributed_trace_async

from ...models import (
    CreateRLEInstanceGroupRequest,
    CreateRLEnvironmentRequest,
    ListRLEInstanceGroupsResponse,
    ListRLEnvironmentVersionsResponse,
    ListRLEnvironmentsResponse,
    RLEInstance,
    RLEInstanceGroup,
    RLEInstanceStatus,
    RLEnvironment,
    RLEnvironmentState,
    RLEnvironmentVersionBump,
    RLEPaginationOrder,
    RLEStepRequest,
    RLEStepResult,
)
from ...rle._rollout_models import HarnessConfiguration, RolloutPolicy, RolloutResult, SamplingOptions
from ...operations._patch_rle_rollout import (
    EXECUTE_ROLLOUT_API_VERSION,
    RLERolloutError,
    build_rollout_body,
    build_rollout_request,
    deserialize_rollout_response,
)
from ...operations._patch_rle import (
    _DEFAULT_INSTANCE_ACQUIRE_TIMEOUT_S,
    _DEFAULT_POLL_INTERVAL_S,
    _OpenEnvWebSocketConfig,
    _TRANSIENT_HEALTH_STATUS_CODES,
    _WEBSOCKET_LOGGER,
    _WEBSOCKET_ATTEMPT_TIMEOUT_S,
    _WEBSOCKET_CONNECT_ATTEMPTS,
    _WEBSOCKET_CONNECTION_TIMEOUT_S,
    _build_openenv_websocket_url,
    _capacity_retry,
    _error_code,
    _is_quota_exceeded_error,
    _parse_retry_after,
    _status_matches,
    _is_retryable_websocket_error,
    _remaining_websocket_timeout,
    _websocket_retry_delay,
    _validate_instance_acquire_timeout,
    _validate_pagination_limit,
    _validate_poll_interval,
    _websocket_config_from_client_config,
    coerce_action,
    coerce_reset_body,
    RLEError,
    RLEInstanceAcquireTimeoutError,
    RLEQuotaExceededError,
)
from ._operations import (
    RLEnvironmentsOperations as _RLEnvironmentsOperationsGenerated,
    RLEInstanceGroupsOperations,
    RLEInstancesOperations,
    RLEInstanceRuntimeOperations,
)

if TYPE_CHECKING:
    from azure.core.credentials_async import AsyncTokenCredential
    from ._rollout_client_async import AsyncRolloutClient


_LOGGER = logging.getLogger(__name__)


async def _connect_openenv_websocket(
    url: str,
    *,
    token: str,
    subprotocols: Optional[Sequence[Subprotocol]],
    additional_headers: Optional[Mapping[str, str]] = None,
    timeout: float = _WEBSOCKET_CONNECTION_TIMEOUT_S,
    max_size: Optional[int] = None,
    close_timeout: Optional[float] = None,
) -> ClientConnection:
    deadline = time.monotonic() + min(timeout, _WEBSOCKET_CONNECTION_TIMEOUT_S)
    options: Dict[str, Any] = {}
    if max_size is not None:
        options["max_size"] = max_size
    if close_timeout is not None:
        options["close_timeout"] = close_timeout
    for attempt in range(_WEBSOCKET_CONNECT_ATTEMPTS):
        try:
            return await websocket_connect(
                url,
                additional_headers={**(additional_headers or {}), "Authorization": "Bearer " + token},
                open_timeout=min(
                    _WEBSOCKET_ATTEMPT_TIMEOUT_S,
                    _remaining_websocket_timeout(deadline),
                ),
                subprotocols=subprotocols,
                logger=_WEBSOCKET_LOGGER,
                **options,
            )
        except (
            EOFError,
            OSError,
            TimeoutError,
            InvalidMessage,
            InvalidStatus,
            _InvalidProxyStatus,
        ) as exc:
            if attempt == _WEBSOCKET_CONNECT_ATTEMPTS - 1 or not _is_retryable_websocket_error(exc):
                raise
            backoff = _websocket_retry_delay(attempt)
            if deadline - time.monotonic() <= backoff:
                raise TimeoutError("timed out while opening the OpenEnv WebSocket") from exc
            await asyncio.sleep(backoff)
    raise AssertionError("unreachable")


class AsyncOpenEnvWebSocket:
    """An asynchronous WebSocket connection to a leased OpenEnv instance.

    Create this connection with :meth:`AsyncOpenEnvInstance.open_websocket` and use it as an async
    context manager. Text and binary messages are supported. The service preserves message
    fragmentation, negotiates requested subprotocols with the sandbox, and propagates peer close
    status and reason. The opening handshake makes up to three attempts for transient connectivity
    failures and HTTP 408, 429, 500, 502, 503, and 504 responses. Retries use full-jitter delays of
    up to two and four seconds within a 90-second overall connection deadline. After the connection
    is established, automatic reconnect and application-level session resumption aren't supported.

    :param url: Public RLE WebSocket URL. Required.
    :type url: str
    :keyword credential: Credential used to authenticate the WebSocket handshake. Required.
    :paramtype credential: ~azure.core.credentials_async.AsyncTokenCredential
    :keyword credential_scopes: OAuth scopes used to request the handshake token. Required.
    :paramtype credential_scopes: tuple[str, ...]
    :keyword subprotocols: WebSocket subprotocols to offer to the sandbox, in preference order.
    :paramtype subprotocols: sequence[str] or None
    """

    def __init__(
        self,
        url: str,
        *,
        credential: "AsyncTokenCredential",
        credential_scopes: Sequence[str],
        subprotocols: Optional[Sequence[str]] = None,
        _on_close: Optional[Callable[["AsyncOpenEnvWebSocket"], None]] = None,
    ) -> None:
        self._url = url
        self._credential = credential
        self._credential_scopes = tuple(credential_scopes)
        self._subprotocols = tuple(Subprotocol(value) for value in subprotocols) if subprotocols else None
        self._on_close = _on_close
        self._connection: Optional[ClientConnection] = None
        self._closed = False

    async def __aenter__(self) -> "AsyncOpenEnvWebSocket":
        if self._closed:
            raise RLEError("OpenEnv WebSocket is closed")
        if self._connection is not None:
            raise RLEError("OpenEnv WebSocket context is already entered")
        try:
            token = await self._credential.get_token(*self._credential_scopes)
            self._connection = await _connect_openenv_websocket(
                self._url,
                token=token.token,
                subprotocols=self._subprotocols,
            )
        except BaseException:
            await self.close()
            raise
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def send(self, message: Union[str, bytes]) -> None:
        """Send one complete text or binary message.

        :param message: Text or binary data to send. Required.
        :type message: str or bytes
        :raises TypeError: If ``message`` is not a string or bytes.
        :raises ~azure.ai.projects.RLEError: If the connection is not open.
        """
        if not isinstance(message, (str, bytes)):
            raise TypeError("OpenEnv WebSocket messages must be strings or bytes")
        await self._require_connection().send(message)

    async def recv(self) -> Union[str, bytes]:
        """Receive one complete text or binary message.

        :return: The received text or binary data.
        :rtype: str or bytes
        :raises ~azure.ai.projects.RLEError: If the connection is not open.
        """
        return await self._require_connection().recv()

    @property
    def subprotocol(self) -> Optional[str]:
        """The subprotocol selected by the sandbox, if any.

        :rtype: str or None
        """
        return self._require_connection().subprotocol

    async def close(self) -> None:
        """Close the connection. This method is idempotent."""
        self._closed = True
        connection = self._connection
        self._connection = None
        try:
            if connection is not None:
                await connection.close()
        finally:
            on_close = self._on_close
            self._on_close = None
            if on_close is not None:
                on_close(self)

    def _require_connection(self) -> ClientConnection:
        if self._connection is None:
            raise RLEError("enter the AsyncOpenEnvWebSocket context before sending or receiving")
        return self._connection


async def _sleep_before_deadline(delay: float, deadline: float) -> bool:
    remaining = deadline - time.monotonic()
    if remaining <= 0 or delay >= remaining:
        return False
    await asyncio.sleep(max(0.0, delay))
    return True


async def _acquire_instance(
    instances: RLEInstancesOperations,
    runtime: RLEInstanceRuntimeOperations,
    environment_name: str,
    environment_version: str,
    instance_group_id: str,
    *,
    instance_acquire_timeout: float,
    poll_interval_s: float,
) -> RLEInstance:
    """Acquire an instance under a group and wait until its runtime reports healthy.

    The service may answer the create request with ``202`` (accepted, still provisioning). The create
    operation is not idempotent, so the pending instance returned by the ``202`` is polled by its id
    (honoring any ``Retry-After`` hint on the first wait) until it reports ``Running`` -- the create is
    never re-issued. A ``429`` ``InstanceGroupAtCapacity`` response is retried using its
    ``Retry-After`` hint until the shared acquisition deadline expires. Once control-plane status is
    ``Running``, the runtime health endpoint is polled until it reports healthy.

    :param instances: Generated async instance operations bound to the project client.
    :type instances: ~azure.ai.projects.aio.operations.RLEInstancesOperations
    :param runtime: Generated async instance runtime operations bound to the project client.
    :type runtime: ~azure.ai.projects.aio.operations.RLEInstanceRuntimeOperations
    :param environment_name: The environment that owns the instance group.
    :type environment_name: str
    :param environment_version: Resolved environment version that owns the instance group.
    :type environment_version: str
    :param instance_group_id: The instance group to lease an instance from.
    :type instance_group_id: str
    :keyword instance_acquire_timeout: Maximum time to acquire a healthy instance, in seconds.
    :paramtype instance_acquire_timeout: float
    :keyword poll_interval_s: Interval between instance readiness polls, in seconds.
    :paramtype poll_interval_s: float
    :return: The leased instance, once it reports ``Running`` and healthy.
    :rtype: ~azure.ai.projects.rle.Instance
    """
    deadline = time.monotonic() + instance_acquire_timeout
    captured: Dict[str, Any] = {}

    def _capture(pipeline_response: Any, deserialized: Any, _response_headers: Any) -> Any:
        captured["response"] = pipeline_response.http_response
        return deserialized

    while True:
        captured.clear()
        try:
            instance = await instances.create_instance(
                environment_name,
                environment_version,
                instance_group_id,
                cls=_capture,
            )
            break
        except HttpResponseError as exc:
            capacity_retry = _capacity_retry(exc, poll_interval_s)
            if capacity_retry is None:
                raise
            details, retry_after = capacity_retry
            if not await _sleep_before_deadline(retry_after, deadline):
                raise RLEInstanceAcquireTimeoutError(
                    f"instance group {instance_group_id} remained at capacity for " f"{instance_acquire_timeout:.0f}s",
                    timeout=instance_acquire_timeout,
                    last_status=_error_code(details),
                    details=details,
                ) from exc
    if instance is None or not instance.instance_id:
        raise RLEError("service did not return an instance id")
    instance_id = instance.instance_id

    # The initial (possibly 202) response may carry a Retry-After hint for the first poll.
    initial_retry_after = _parse_retry_after(captured.get("response"))
    next_wait = initial_retry_after if initial_retry_after is not None else poll_interval_s
    try:
        while not _status_matches(instance.status, RLEInstanceStatus.RUNNING):
            if any(
                _status_matches(instance.status, terminal_status)
                for terminal_status in (
                    RLEInstanceStatus.STOPPED,
                    RLEInstanceStatus.FAILED,
                    RLEInstanceStatus.DELETED,
                )
            ):
                raise RLEError(f"instance {instance_id} failed to start: {instance.error or 'unknown error'}")
            if time.monotonic() >= deadline:
                last_status = str(getattr(instance.status, "value", instance.status) or "unknown")
                raise RLEInstanceAcquireTimeoutError(
                    f"instance {instance_id} not ready after {instance_acquire_timeout:.0f}s "
                    f"(last status: {last_status})",
                    timeout=instance_acquire_timeout,
                    last_status=last_status,
                )
            if not await _sleep_before_deadline(next_wait, deadline):
                last_status = str(getattr(instance.status, "value", instance.status) or "unknown")
                raise RLEInstanceAcquireTimeoutError(
                    f"instance {instance_id} not ready after {instance_acquire_timeout:.0f}s "
                    f"(last status: {last_status})",
                    timeout=instance_acquire_timeout,
                    last_status=last_status,
                )
            next_wait = poll_interval_s
            instance = await instances.get_instance(
                environment_name,
                environment_version,
                instance_group_id,
                instance_id,
            )

        while True:
            try:
                await runtime.health(
                    environment_name,
                    environment_version,
                    instance_group_id,
                    instance_id,
                )
                break
            except HttpResponseError as exc:
                if getattr(exc.response, "status_code", None) not in _TRANSIENT_HEALTH_STATUS_CODES:
                    raise
            if not await _sleep_before_deadline(poll_interval_s, deadline):
                raise RLEInstanceAcquireTimeoutError(
                    f"instance {instance_id} runtime was not healthy after " f"{instance_acquire_timeout:.0f}s",
                    timeout=instance_acquire_timeout,
                    last_status="Unhealthy",
                )
    except BaseException:
        # The instance was leased but never became usable; release it so it does not leak quota.
        try:
            await instances.delete_instance(
                environment_name,
                environment_version,
                instance_group_id,
                instance_id,
            )
        except Exception:  # pylint: disable=broad-except
            pass
        raise
    return instance


class AsyncOpenEnvInstance:  # pylint: disable=too-many-instance-attributes
    """A leased RLE instance that runs episodes under a resolved environment version.

    An instance context is obtained from :meth:`AsyncOpenEnvClient.get_instance`. Entering it leases a
    running :class:`~azure.ai.projects.rle.Instance`; the instance then drives the OpenEnv /
    Gymnasium runtime operations (``reset``/``step``/``state``). Each :meth:`reset` starts a new
    episode, so an instance may run one or more episodes while it is checked out. Exiting the
    instance's ``async with`` block releases the underlying instance immediately.

    :param environment_name: The environment that owns the instance group. Required.
    :type environment_name: str
    :param instance_group_id: The instance group to lease from. Required.
    :type instance_group_id: str
    :keyword environment_version: Resolved environment version that owns the instance group.
    :paramtype environment_version: str
    :keyword instances: Generated async instance lifecycle operations bound to the project client. Required.
    :paramtype instances: ~azure.ai.projects.aio.operations.RLEInstancesOperations
    :keyword runtime: Generated async instance runtime operations bound to the project client. Required.
    :paramtype runtime: ~azure.ai.projects.aio.operations.RLEInstanceRuntimeOperations
    """

    def __init__(
        self,
        environment_name: str,
        instance_group_id: str,
        *,
        environment_version: str,
        instances: RLEInstancesOperations,
        runtime: RLEInstanceRuntimeOperations,
        instance_acquire_timeout: float,
        poll_interval_s: float,
        is_client_closed: Callable[[], bool],
        websocket_config: Optional[_OpenEnvWebSocketConfig] = None,
    ) -> None:
        if not environment_name:
            raise ValueError("environment_name is required")
        if not instance_group_id:
            raise ValueError("instance_group_id is required")
        if not environment_version:
            raise ValueError("environment_version is required")
        self._environment_name = environment_name
        self._environment_version = environment_version
        self._instance_group_id = instance_group_id
        self._instances = instances
        self._runtime = runtime
        self._acquire_settings = (
            _validate_instance_acquire_timeout(instance_acquire_timeout),
            _validate_poll_interval(poll_interval_s),
        )
        self._is_client_closed = is_client_closed
        self._websocket_config = websocket_config
        self._websockets: set[AsyncOpenEnvWebSocket] = set()
        self._instance: Optional[RLEInstance] = None
        self._released = False
        self._releasing = False
        self._lock = asyncio.Lock()

    @property
    def id(self) -> str:
        """Identifier of the leased instance that backs this object.

        :rtype: str
        """
        instance = self._instance
        if instance is None:
            if self._released:
                raise RLEError("instance has been released")
            raise RLEError("enter the AsyncOpenEnvInstance context before accessing the instance")
        if not instance.instance_id:
            raise RLEError("service did not return an instance id")
        return instance.instance_id

    @property
    def instance_group_id(self) -> str:
        """The instance group the instance was leased from.

        :rtype: str
        """
        return self._instance_group_id

    @property
    def environment_name(self) -> str:
        """Resolved environment name that owns this instance.

        :rtype: str
        """
        return self._environment_name

    @property
    def environment_version(self) -> str:
        """Resolved environment version that owns this instance.

        :rtype: str
        """
        return self._environment_version

    @property
    def instance(self) -> RLEInstance:
        """The underlying leased instance model.

        :rtype: ~azure.ai.projects.rle.Instance
        """
        if self._instance is None:
            if self._released:
                raise RLEError("instance has been released")
            raise RLEError("enter the AsyncOpenEnvInstance context before accessing the instance")
        return self._instance

    async def __aenter__(self) -> "AsyncOpenEnvInstance":
        async with self._lock:
            if self._released:
                raise RLEError("instance has been released")
            if self._instance is not None:
                raise RLEError("AsyncOpenEnvInstance context is already entered")
            if self._is_client_closed():
                raise RLEError("OpenEnv client is closed")
            instance = await _acquire_instance(
                self._instances,
                self._runtime,
                self._environment_name,
                self._environment_version,
                self._instance_group_id,
                instance_acquire_timeout=self._acquire_settings[0],
                poll_interval_s=self._acquire_settings[1],
            )
            self._instance = instance
        if self._is_client_closed():
            await self.release()
            raise RLEError("OpenEnv client is closed")
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.release()

    async def release(self) -> None:
        """Release this leased instance on the service, best effort.

        Invoked automatically on context exit. v1 does not reuse instances: once an instance leaves
        its ``async with`` block the underlying instance is released immediately, which frees its slot
        in the group's reservation so another instance can be leased.
        """
        await self._release()

    def open_websocket(
        self,
        *,
        subprotocols: Optional[Sequence[str]] = None,
        query_parameters: Optional[Mapping[str, str]] = None,
    ) -> AsyncOpenEnvWebSocket:
        """Create an async WebSocket context manager for this leased instance.

        The connection authenticates through the Foundry project endpoint. It performs no automatic
        reconnect or message replay. Query parameters and requested subprotocols are forwarded to the
        sandbox.

        :keyword subprotocols: WebSocket subprotocols to offer to the sandbox, in preference order.
        :paramtype subprotocols: sequence[str] or None
        :keyword query_parameters: Additional query parameters to forward to the sandbox.
        :paramtype query_parameters: mapping[str, str] or None
        :return: An async WebSocket context manager for complete text or binary messages.
        :rtype: ~azure.ai.projects.aio.operations.AsyncOpenEnvWebSocket
        """
        if self._releasing or self._released:
            raise RLEError("instance has been released")
        instance = self._instance
        if instance is None:
            raise RLEError("enter the AsyncOpenEnvInstance context before accessing the instance")
        if not instance.instance_id:
            raise RLEError("service did not return an instance id")
        config = self._websocket_config
        if config is None:
            raise RLEError("OpenEnv WebSocket configuration is unavailable")
        websocket = AsyncOpenEnvWebSocket(
            _build_openenv_websocket_url(
                config,
                self._environment_name,
                self._environment_version,
                self._instance_group_id,
                instance.instance_id,
                query_parameters,
            ),
            credential=config.credential,
            credential_scopes=config.credential_scopes,
            subprotocols=subprotocols,
            _on_close=self._websockets.discard,
        )
        self._websockets.add(websocket)
        return websocket

    @distributed_trace_async
    async def reset(
        self,
        seed: Optional[int] = None,
        episode_id: Optional[str] = None,
        **kwargs: Any,
    ) -> RLEStepResult:
        """Start a new episode on this instance and return the initial observation.

        Additional keyword arguments are forwarded to the environment as extra top-level reset
        fields alongside ``seed`` and ``episode_id``, mirroring environment-specific fields passed
        to :meth:`step`.

        :param seed: Optional seed for deterministic episode initialization.
        :type seed: int or None
        :param episode_id: Optional caller-supplied episode identifier.
        :type episode_id: str or None
        :return: The initial step result for the new episode.
        :rtype: ~azure.ai.projects.rle.StepResult
        """
        await self._ensure_healthy()
        return await self._runtime.reset(
            self._environment_name,
            self._environment_version,
            self._instance_group_id,
            self.id,
            coerce_reset_body(seed, episode_id, kwargs),
        )

    @distributed_trace_async
    async def step(self, action: Any = None, **action_kwargs: Any) -> RLEStepResult:
        """Apply an action and return the resulting observation, reward, and done state.

        :param action: The action to apply, as a mapping or model. Mutually exclusive with keyword fields.
        :type action: any
        :return: The step result after applying the action.
        :rtype: ~azure.ai.projects.rle.StepResult
        """
        await self._ensure_healthy()
        return await self._runtime.step(
            self._environment_name,
            self._environment_version,
            self._instance_group_id,
            self.id,
            RLEStepRequest(action=coerce_action(action, action_kwargs)),
        )

    @distributed_trace_async
    async def state(self) -> RLEnvironmentState:
        """Return the current environment state for this instance.

        :return: The current environment state.
        :rtype: ~azure.ai.projects.rle.EnvironmentState
        """
        await self._ensure_healthy()
        return await self._runtime.state(
            self._environment_name,
            self._environment_version,
            self._instance_group_id,
            self.id,
        )

    @distributed_trace_async
    async def health(self) -> Dict[str, Any]:
        """Return instance health information.

        :return: Instance health information.
        :rtype: dict[str, any]
        """
        return await self._runtime.health(
            self._environment_name,
            self._environment_version,
            self._instance_group_id,
            self.id,
        )

    @distributed_trace_async
    async def metadata(self) -> Dict[str, Any]:
        """Return instance metadata.

        :return: Instance metadata.
        :rtype: dict[str, any]
        """
        await self._ensure_healthy()
        return await self._runtime.get_metadata(
            self._environment_name,
            self._environment_version,
            self._instance_group_id,
            self.id,
        )

    @distributed_trace_async
    async def schema(self) -> Dict[str, Any]:
        """Return the instance action and observation schema.

        :return: The instance action and observation schema.
        :rtype: dict[str, any]
        """
        await self._ensure_healthy()
        return await self._runtime.schema(
            self._environment_name,
            self._environment_version,
            self._instance_group_id,
            self.id,
        )

    async def _ensure_healthy(self) -> None:
        await self.health()

    async def _release(self) -> None:
        """Release the underlying instance, best effort."""
        async with self._lock:
            instance = self._instance
            if instance is None:
                return
            instance_id = self.id
            self._releasing = True
            try:
                for websocket in tuple(self._websockets):
                    try:
                        await websocket.close()
                    except Exception as exc:  # pylint: disable=broad-exception-caught
                        _LOGGER.warning(
                            "Failed to close OpenEnv WebSocket before releasing instance %s: %s",
                            instance_id,
                            type(exc).__name__,
                        )
                try:
                    await self._instances.delete_instance(
                        self._environment_name,
                        self._environment_version,
                        self._instance_group_id,
                        instance_id,
                    )
                except AzureError:
                    pass
            except BaseException:
                self._releasing = False
                raise
            self._instance = None
            self._released = True
            self._releasing = False


class AsyncOpenEnvClient:  # pylint: disable=too-many-instance-attributes,async-client-bad-name,client-accepts-api-version-keyword,missing-client-constructor-parameter-credential,missing-client-constructor-parameter-kwargs
    """An async client over a hosted RLE (OpenEnv) environment with a reserved concurrency quota.

    Created via :meth:`RLEOperations.get_openenv_client`. On entering its context the client creates a
    single instance group under ``name`` (optionally pinned to ``version``) that reserves
    ``max_active_instances`` concurrent
    instances on the service and fails immediately if that quota cannot be granted -- there is no
    queueing. The service owns the reservation and the pool of instances; this client keeps no local
    pool. Future revisions may relax this with queueing and elastic scaling.

    :meth:`get_instance` leases a running :class:`AsyncOpenEnvInstance` from the group on demand.
    Because each :meth:`AsyncOpenEnvInstance.reset` starts a fresh episode, an instance may run one or
    more episodes while checked out; exiting its context releases the underlying instance immediately
    (v1 does not reuse instances). Leasing more than ``max_active_instances`` at once fails until an
    outstanding instance is released. Closing the client deletes the group, which releases any
    instances still leased on the service; the client keeps no local list of leased instances.

    :keyword environments: Generated async environment operations used to resolve the environment. Required.
    :paramtype environments: ~azure.ai.projects.aio.operations.RLEnvironmentsOperations
    :keyword instance_groups: Generated async instance group operations bound to the project client. Required.
    :paramtype instance_groups: ~azure.ai.projects.aio.operations.RLEInstanceGroupsOperations
    :keyword instances: Generated async instance lifecycle operations bound to the project client. Required.
    :paramtype instances: ~azure.ai.projects.aio.operations.RLEInstancesOperations
    :keyword runtime: Generated async instance runtime operations bound to the project client. Required.
    :paramtype runtime: ~azure.ai.projects.aio.operations.RLEInstanceRuntimeOperations
    :keyword name: The hosted RLE environment name to resolve. Required.
    :paramtype name: str
    :keyword version: Optional environment image version to resolve and lease against.
    :paramtype version: str or None
    :keyword max_active_instances: Concurrency to reserve on the group. Defaults to 1.
    :paramtype max_active_instances: int
    :keyword instance_acquire_timeout: Maximum time to wait for capacity, provisioning, and runtime
     health when leasing an instance, in seconds. Defaults to 900 and is capped at 3600.
    :paramtype instance_acquire_timeout: float
    :keyword poll_interval_s: Interval between instance readiness polls, in seconds. Default value is 5.
    :paramtype poll_interval_s: float
    """

    def __init__(
        self,
        *,
        environments: _RLEnvironmentsOperationsGenerated,
        instance_groups: RLEInstanceGroupsOperations,
        instances: RLEInstancesOperations,
        runtime: RLEInstanceRuntimeOperations,
        websocket_config: Optional[_OpenEnvWebSocketConfig] = None,
        name: str,
        version: Optional[str] = None,
        max_active_instances: int = 1,
        instance_acquire_timeout: float = _DEFAULT_INSTANCE_ACQUIRE_TIMEOUT_S,
        poll_interval_s: float = _DEFAULT_POLL_INTERVAL_S,
    ) -> None:
        if not name:
            raise ValueError("name is required")
        if max_active_instances < 1:
            raise ValueError("max_active_instances must be >= 1")
        self._environments = environments
        self._instance_groups = instance_groups
        self._instances = instances
        self._runtime = runtime
        self._websocket_config = websocket_config
        self._name = name
        self._version = version
        self._max_active_instances = max_active_instances
        self._acquire_settings = (
            _validate_instance_acquire_timeout(instance_acquire_timeout),
            _validate_poll_interval(poll_interval_s),
        )
        self._instance_group_id: Optional[str] = None
        self._lock = asyncio.Lock()
        self._closed = False

    @property
    def instance_group_id(self) -> Optional[str]:
        """The instance group id backing this client, once created (else ``None``).

        :rtype: str or None
        """
        return self._instance_group_id

    @property
    def max_active_instances(self) -> int:
        """Concurrency the instance group reserves on the service for this client.

        :rtype: int
        """
        return self._max_active_instances

    @property
    def environment_name(self) -> str:
        """Environment name, resolved from the instance-group response after context entry.

        :rtype: str
        """
        return self._name

    @property
    def environment_version(self) -> Optional[str]:
        """Resolved environment version after context entry, otherwise the requested version.

        :rtype: str or None
        """
        return self._version

    async def __aenter__(self) -> "AsyncOpenEnvClient":
        await self._ensure_group()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    async def _ensure_group(self) -> None:
        """Create the instance group that reserves this client's concurrency on the service.

        Idempotent: a second call is a no-op once the group exists. The group reserves capacity for
        ``max_active_instances`` concurrent instances; the service owns that reservation and the pool, and
        hands instances out (tracking how many remain) as :meth:`get_instance` leases them. If the
        quota cannot be satisfied the service returns ``403`` and this raises
        :class:`RLEQuotaExceededError` (v1 fails fast rather than queueing).
        """
        async with self._lock:
            if self._instance_group_id is not None:
                return
            if self._closed:
                raise RLEError("OpenEnv client is closed")
            if self._version is None:
                environment = await self._environments.get_environment(self._name)
                if not environment.version:
                    raise RLEError("service did not return the environment's latest version")
                self._version = environment.version
            try:
                group = await self._instance_groups.create_instance_group(
                    self._name,
                    self._version,
                    CreateRLEInstanceGroupRequest(
                        max_active_instances=self._max_active_instances,
                    ),
                )
            except HttpResponseError as exc:
                if _is_quota_exceeded_error(exc):
                    raise RLEQuotaExceededError(
                        f"quota exceeded creating an instance group for environment '{self._name}'"
                    ) from exc
                raise
            if not group.instance_group_id:
                raise RLEError("service did not return an instance group id")
            if not group.environment_name or not group.environment_version:
                try:
                    await self._instance_groups.delete_instance_group(
                        self._name,
                        self._version,
                        group.instance_group_id,
                    )
                except AzureError:
                    pass
                raise RLEError("service did not return the instance group's environment name and version")
            self._name = group.environment_name
            self._version = group.environment_version
            self._instance_group_id = group.instance_group_id

    def get_instance(self) -> AsyncOpenEnvInstance:
        """Create an async context manager that leases a running instance on entry.

        This method performs no I/O. Entering the returned async context manager creates an instance
        under the group and waits (up to ``instance_acquire_timeout``) for capacity, ``Running``
        status, and runtime health. Because
        the group reserves ``max_active_instances`` concurrent instances, temporary capacity responses
        are retried until capacity becomes available or the acquisition timeout expires.

        The returned :class:`AsyncOpenEnvInstance` is an async context manager; exiting its context
        releases the underlying instance back to the service immediately (v1 does not reuse instances).
        The service owns the pool and the reservation, so this client keeps no local bookkeeping of
        leased instances; closing the client deletes the group, which releases any instances still
        leased.

        :return: An async context manager that yields a leased instance ready to run episodes.
        :rtype: ~azure.ai.projects.aio.operations.AsyncOpenEnvInstance
        """
        if self._closed:
            raise RLEError("OpenEnv client is closed")
        group_id = self._instance_group_id
        if group_id is None:
            raise RLEError("reserve quota first: enter the AsyncOpenEnvClient context before get_instance()")
        environment_version = self._version
        if environment_version is None:
            raise RLEError("service did not resolve the instance group's environment version")
        return AsyncOpenEnvInstance(
            self._name,
            group_id,
            environment_version=environment_version,
            instances=self._instances,
            runtime=self._runtime,
            instance_acquire_timeout=self._acquire_settings[0],
            poll_interval_s=self._acquire_settings[1],
            is_client_closed=lambda: self._closed,
            websocket_config=self._websocket_config,
        )

    async def close(self) -> None:
        """Tear down the instance group, best effort.

        The service releases any instances still leased under the group when it is deleted, so this
        client does not release them individually.
        """
        async with self._lock:
            if self._closed:
                return
            self._closed = True
            try:
                await self._close_group_locked()
            except asyncio.CancelledError:
                self._closed = False
                raise

    async def _close_group_locked(self) -> None:
        group_id = self._instance_group_id
        if group_id is None:
            return
        environment_version = self._version
        if environment_version is None:
            raise RLEError("service did not resolve the instance group's environment version")
        try:
            await self._instance_groups.delete_instance_group(
                self._name,
                environment_version,
                group_id,
            )
        except AzureError:
            pass
        self._instance_group_id = None


class RLEOperations:
    """Async operations for hosted RLE environments, accessed through the client's ``rle`` attribute.

    This operation group exposes environment management (:meth:`create_environment`,
    :meth:`list_environments`, :meth:`get_environment`, :meth:`get_environment_version`,
    :meth:`list_environment_versions`, :meth:`delete_environment_version`) alongside
    :meth:`get_openenv_client`, which resolves a hosted RLE environment and returns an
    :class:`AsyncOpenEnvClient`. Episodes are then driven through that client and the
    :class:`AsyncOpenEnvInstance` objects it hands out (reset/step/state/health/metadata/schema).
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        config = args[1] if len(args) > 1 else kwargs.get("config")
        self._websocket_config = _websocket_config_from_client_config(config)
        self._pipeline_client = args[0] if args else kwargs.get("client")
        self._config = config
        self._environments = _RLEnvironmentsOperationsGenerated(*args, **kwargs)
        self._instance_groups = RLEInstanceGroupsOperations(*args, **kwargs)
        self._instances = RLEInstancesOperations(*args, **kwargs)
        self._runtime = RLEInstanceRuntimeOperations(*args, **kwargs)

    @distributed_trace_async
    async def create_environment(
        self,
        acr_image_path: str,
        *,
        name: Optional[str] = None,
        version_bump: Optional[Union[str, RLEnvironmentVersionBump]] = None,
        **kwargs: Any,
    ) -> RLEnvironment:
        """Create a new hosted RLE environment.

        :param acr_image_path: Azure Container Registry image path that backs the environment. Required.
        :type acr_image_path: str
        :keyword name: Optional environment name. The service assigns one when omitted.
        :paramtype name: str or None
        :keyword version_bump: Semantic version component to increment. Omit to let the service choose.
        :paramtype version_bump: str or ~azure.ai.projects.rle.EnvironmentVersionBump or None
        :return: The created RLEnvironment.
        :rtype: ~azure.ai.projects.rle.Environment
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        if not acr_image_path:
            raise ValueError("acr_image_path is required")
        return await self._environments.create_environment(
            CreateRLEnvironmentRequest(name=name, acr_image_path=acr_image_path, version_bump=version_bump),
            **kwargs,
        )

    @distributed_trace
    def list_environments(
        self,
        *,
        name: Optional[str] = None,
        limit: Optional[int] = None,
        continuation_token: Optional[str] = None,
        order: Optional[Union[str, RLEPaginationOrder]] = None,
        **kwargs: Any,
    ) -> AsyncItemPaged[RLEnvironment]:
        """List all hosted RLE environments in the project.

        :keyword name: Optional environment name filter. When set, returns at most a single matching
         environment. Default value is None.
        :paramtype name: str or None
        :keyword limit: Maximum number of environments to return. Valid range is [1, 100].
        :paramtype limit: int or None
        :keyword continuation_token: Opaque continuation token from a previous page. Omit to fetch the first page.
        :paramtype continuation_token: str or None
        :keyword order: Sort order for the page. Known values are "asc" and "desc".
        :paramtype order: str or ~azure.ai.projects.rle.PaginationOrder or None
        :return: An async iterator over hosted RLE environments.
        :rtype: ~azure.core.async_paging.AsyncItemPaged[~azure.ai.projects.rle.Environment]
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        _validate_pagination_limit(limit)
        operation_kwargs = dict(kwargs)

        async def get_next(
            next_token: Optional[str] = None,
        ) -> ListRLEnvironmentsResponse:
            return await self._environments.list_environments(
                name=name,
                limit=limit,
                continuation_token_parameter=(continuation_token if next_token is None else next_token),
                order=order,
                **operation_kwargs,
            )

        async def extract_data(
            response: ListRLEnvironmentsResponse,
        ) -> tuple[Optional[str], AsyncList[RLEnvironment]]:
            return response.next_continuation_token, AsyncList(response.data)

        return AsyncItemPaged(get_next, extract_data)

    @distributed_trace_async
    async def get_environment(self, name: str, **kwargs: Any) -> RLEnvironment:
        """Get a hosted RLE environment by name. Returns the latest version of the environment.

        :param name: Environment name. Required.
        :type name: str
        :return: The requested RLEnvironment.
        :rtype: ~azure.ai.projects.rle.Environment
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        return await self._environments.get_environment(name, **kwargs)

    @distributed_trace_async
    async def get_environment_version(self, name: str, version: str, **kwargs: Any) -> RLEnvironment:
        """Get a specific version of a hosted RLE environment by name and version.

        :param name: Environment name. Required.
        :type name: str
        :param version: Environment version identifier. Required.
        :type version: str
        :return: The requested RLEnvironment at the given version.
        :rtype: ~azure.ai.projects.rle.Environment
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        return await self._environments.get_environment_version(name, version, **kwargs)

    @distributed_trace
    def list_environment_versions(
        self,
        name: str,
        *,
        limit: Optional[int] = None,
        continuation_token: Optional[str] = None,
        order: Optional[Union[str, RLEPaginationOrder]] = None,
        **kwargs: Any,
    ) -> AsyncItemPaged[RLEnvironment]:
        """List historical versions of a hosted RLE environment.

        :param name: Environment name. Required.
        :type name: str
        :keyword limit: Maximum number of versions to return. Valid range is [1, 100].
        :paramtype limit: int or None
        :keyword continuation_token: Opaque continuation token from a previous page. Omit to fetch the first page.
        :paramtype continuation_token: str or None
        :keyword order: Sort order for the page. Known values are "asc" and "desc".
        :paramtype order: str or ~azure.ai.projects.rle.PaginationOrder or None
        :return: An async iterator over historical environment versions.
        :rtype: ~azure.core.async_paging.AsyncItemPaged[~azure.ai.projects.rle.Environment]
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        _validate_pagination_limit(limit)
        operation_kwargs = dict(kwargs)

        async def get_next(
            next_token: Optional[str] = None,
        ) -> ListRLEnvironmentVersionsResponse:
            return await self._environments.list_rl_environment_versions(
                name,
                limit=limit,
                continuation_token_parameter=(continuation_token if next_token is None else next_token),
                order=order,
                **operation_kwargs,
            )

        async def extract_data(
            response: ListRLEnvironmentVersionsResponse,
        ) -> tuple[Optional[str], AsyncList[RLEnvironment]]:
            return response.next_continuation_token, AsyncList(response.data)

        return AsyncItemPaged(get_next, extract_data)

    @distributed_trace
    def list_instance_groups(
        self,
        environment_name: str,
        environment_version: str,
        *,
        limit: Optional[int] = None,
        continuation_token: Optional[str] = None,
        order: Optional[Union[str, RLEPaginationOrder]] = None,
        **kwargs: Any,
    ) -> AsyncItemPaged[RLEInstanceGroup]:
        """List instance groups for a hosted RLE environment version.

        :param environment_name: Environment name. Required.
        :type environment_name: str
        :param environment_version: Environment version identifier. Required.
        :type environment_version: str
        :keyword limit: Maximum number of instance groups to return. Valid range is [1, 100].
        :paramtype limit: int or None
        :keyword continuation_token: Opaque continuation token from a previous page. Omit to fetch the first page.
        :paramtype continuation_token: str or None
        :keyword order: Sort order for the page. Known values are "asc" and "desc".
        :paramtype order: str or ~azure.ai.projects.rle.PaginationOrder or None
        :return: An async iterator over RLE instance groups.
        :rtype: ~azure.core.async_paging.AsyncItemPaged[~azure.ai.projects.rle.InstanceGroup]
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        _validate_pagination_limit(limit)
        operation_kwargs = dict(kwargs)

        async def get_next(
            next_token: Optional[str] = None,
        ) -> ListRLEInstanceGroupsResponse:
            return await self._instance_groups.list_instance_groups(
                environment_name,
                environment_version,
                limit=limit,
                continuation_token_parameter=(continuation_token if next_token is None else next_token),
                order=order,
                **operation_kwargs,
            )

        async def extract_data(
            response: ListRLEInstanceGroupsResponse,
        ) -> tuple[Optional[str], AsyncList[RLEInstanceGroup]]:
            return response.next_continuation_token, AsyncList(response.data)

        return AsyncItemPaged(get_next, extract_data)

    @distributed_trace_async
    async def delete_environment_version(self, name: str, version: str, **kwargs: Any) -> None:
        """Delete a specific version of a hosted RLE environment.

        :param name: Environment name. Required.
        :type name: str
        :param version: Environment version identifier. Required.
        :type version: str
        :return: None
        :rtype: None
        :raises ~azure.core.exceptions.HttpResponseError:
        """
        await self._environments.delete_environment_version(name, version, **kwargs)

    def get_openenv_client(
        self,
        *,
        name: str,
        version: Optional[str] = None,
        max_active_instances: int = 1,
        instance_acquire_timeout: float = _DEFAULT_INSTANCE_ACQUIRE_TIMEOUT_S,
        poll_interval_s: float = _DEFAULT_POLL_INTERVAL_S,
    ) -> AsyncOpenEnvClient:
        """Create an :class:`AsyncOpenEnvClient` over a hosted RLE environment.

        This constructs the client without any network I/O (no awaiting needed), so callers can write
        ``async with client.rle.get_openenv_client(...) as openenv_client:``. The returned client is an
        async context manager: entering it creates an instance group under ``name`` (and ``version``
        when supplied) -- so a missing or invalid environment fails on entry -- and reserves its
        concurrency on the service, failing fast if that quota cannot be
        granted (v1 does not queue). :meth:`AsyncOpenEnvClient.get_instance` then leases running
        :class:`AsyncOpenEnvInstance` objects from the group on demand to run episodes on.

        :keyword name: The hosted RLE environment name to resolve. Required.
        :paramtype name: str
        :keyword version: Optional environment image version. When set, the instance group is created
         under that version; otherwise the service uses the latest version.
        :paramtype version: str or None
        :keyword max_active_instances: Concurrency to reserve on the group, so that several episodes can run
         concurrently on the event loop. Defaults to 1.
        :paramtype max_active_instances: int
        :keyword instance_acquire_timeout: Maximum time to wait for capacity, provisioning, and
         runtime health when leasing an instance, in seconds. Defaults to 900 and is capped at 3600.
        :paramtype instance_acquire_timeout: float
        :keyword poll_interval_s: Interval between instance readiness polls, in seconds. Default value is 5.
        :paramtype poll_interval_s: float
        :return: An async OpenEnv client bound to this client.
        :rtype: ~azure.ai.projects.aio.operations.AsyncOpenEnvClient
        """
        if not name:
            raise ValueError("name is required")
        return AsyncOpenEnvClient(
            environments=self._environments,
            instance_groups=self._instance_groups,
            instances=self._instances,
            runtime=self._runtime,
            websocket_config=self._websocket_config,
            name=name,
            version=version,
            max_active_instances=max_active_instances,
            instance_acquire_timeout=instance_acquire_timeout,
            poll_interval_s=poll_interval_s,
        )

    async def _forwarded_token(self) -> str:
        """Acquire the bearer RLE forwards to Capture Proxy, from this client's own credential."""
        credential = getattr(self._config, "credential", None)
        scopes = getattr(self._config, "credential_scopes", None)
        if credential is None or not scopes:
            raise RLEError(
                "execute_rollout needs the client's credential to obtain the forwarded token "
                "RLE presents to Loom, and this client was constructed without one."
            )
        token = await credential.get_token(*scopes)
        return token.token

    def get_rollout_client(
        self,
        environment_name: str,
        environment_version: str,
        job_id: Optional[str] = None,
        *,
        server_managed_token_renewal: bool = False,
    ) -> "AsyncRolloutClient":
        """Create a lazy asynchronous shared Execute Rollout client.

        The SDK manages admission for up to 32 concurrent rollouts per client,
        with no public concurrency override. The session owns one active submission socket. Draining
        sockets retain pending results while new work opens a replacement.
        Its per-call timeout
        starts after concurrency admission and includes connection and execution.
        Queue waiting remains cancellable and wakes on closure or a session-level
        protocol failure. An unknown outcome affects only its awaiting call.
        Close the rollout client before the project client.
        If a socket disconnects, only its unfinished rollouts switch to HTTP
        status/result recovery with their original IDs and deadlines. Healthy
        sockets are not polled and submitted execution is never replayed.

        :param environment_name: Published environment name.
        :type environment_name: str
        :param environment_version: Exact published environment version.
        :type environment_version: str
        :param job_id: Optional job identifier attached to every rollout.
        :type job_id: str or None
        :keyword server_managed_token_renewal: Keep a healthy socket open regardless of age or token
            expiry. Requires service-side delegated token renewal and long-lived connections.
            Default False retains age/token-based connection replacement.
        :paramtype server_managed_token_renewal: bool
        :return: A lazy asynchronous context manager with ``execute_rollout`` and async ``close``.
        :rtype: ~azure.ai.projects.aio.operations._rollout_client_async.AsyncRolloutClient
        """
        from ._rollout_client_async import AsyncRolloutClient

        return AsyncRolloutClient(
            self, environment_name, environment_version, job_id,
            server_managed_token_renewal=server_managed_token_renewal,
        )

    @distributed_trace_async
    async def execute_rollout(
        self,
        environment_name: str,
        environment_version: str,
        *,
        task: Any,
        policy: RolloutPolicy,
        sampling: Optional[SamplingOptions] = None,
        harness: Optional[HarnessConfiguration] = None,
        rollout_id: Optional[str] = None,
        forwarded_token: Optional[str] = None,
        transport: str = "http",
        **kwargs: Any,
    ) -> RolloutResult:
        """Run one complete rollout of a published environment version and return what it produced.

        The service owns the episode. It leases a fresh sandbox, resets the environment on
        ``task``, samples the model through Capture Proxy, applies each action, and repeats until
        the environment terminates or the version's step budget is spent. There is no instance to
        lease and no loop to drive: one call in, one finished trajectory out.

        This is the difference from :meth:`get_openenv_client`, where the caller holds an instance
        and does its own sampling between steps. Use that when the policy lives in your process;
        use this when you want the service to run the episode against a named checkpoint.

        The result carries both halves of a training example -- ``reward`` and, in
        ``rollout``, the Capture Proxy graph whose sequences hold the ``input_ids``, ``loss_mask``
        and ``logprobs`` of every turn sampled.

        :param environment_name: Published environment name. Required.
        :type environment_name: str
        :param environment_version: Exact version to run. Required, and never resolved to
         "latest": a rollout names the version that produced it so the trajectory stays
         attributable.
        :type environment_version: str
        :keyword task: Opaque task record -- normally one dataset row -- forwarded unchanged to the
         environment's reset. Required.
        :paramtype task: any
        :keyword policy: Where this rollout's weights come from, and which backend resolves them.
         Required. Use :class:`~azure.ai.projects.models.LoomPolicy` to sample a Loom
         checkpoint, which returns a trainable graph, or :class:`~azure.ai.projects.models.FoundryDeploymentPolicy`
         to sample a model deployment in the project for eval only, which returns none.
        :paramtype policy: ~azure.ai.projects.models.RolloutPolicy
        :keyword sampling: How completions are sampled and rendered. Optional; the service picks a
         compatible renderer when omitted. Not accepted with a Foundry policy.
        :paramtype sampling: ~azure.ai.projects.models.SamplingOptions or None
        :keyword harness: Callable target for this rollout only, for example a BYOH agent URL.
         Optional; the environment version's stored harness is used when omitted.
        :paramtype harness: ~azure.ai.projects.rle.HarnessConfiguration or None
        :keyword rollout_id: Caller-supplied identifier, reserved within the project and returned
         unchanged. A bare-hex UUID is generated when omitted.
        :paramtype rollout_id: str or None
        :keyword forwarded_token: Bearer token RLE forwards to Capture Proxy for Loom sampling.
         Acquired from this client's credential when omitted, which is the common case.
        :paramtype forwarded_token: str or None
        :keyword transport: The existing HTTP transport. Use ``get_rollout_client`` for shared WebSocket execution.
        :paramtype transport: str
        :return: The completed rollout.
        :rtype: ~azure.ai.projects.models.RolloutResult
        :raises ~azure.ai.projects.operations.RLERolloutError: If the service refused the request
         or could not complete the rollout.
        """
        if transport != "http":
            raise ValueError("Use get_rollout_client for WebSocket execution; execute_rollout uses HTTP.")
        if not environment_name:
            raise ValueError("environment_name is required")
        if not environment_version:
            raise ValueError("environment_version is required")

        body = build_rollout_body(
            task=task,
            policy=policy,
            sampling=sampling,
            harness=harness,
            rollout_id=rollout_id,
        )
        request = build_rollout_request(
            environment_name=environment_name,
            environment_version=environment_version,
            body=body,
            forwarded_token=forwarded_token or await self._forwarded_token(),
            api_version=kwargs.pop("api_version", EXECUTE_ROLLOUT_API_VERSION),
        )
        request.url = self._pipeline_client.format_url(  # type: ignore[union-attr]
            request.url, endpoint=self._config.endpoint
        )
        pipeline_response = await self._pipeline_client._pipeline.run(  # pylint: disable=protected-access
            request, stream=False, **kwargs
        )
        response = pipeline_response.http_response
        await response.read()
        return deserialize_rollout_response(response, body.rollout_id)


__all__ = [
    "AsyncOpenEnvClient",
    "AsyncOpenEnvInstance",
    "AsyncOpenEnvWebSocket",
    "RLEError",
    "RLEQuotaExceededError",
    "RLEInstanceAcquireTimeoutError",
    "RLERolloutError",
    "RLEOperations",
    "coerce_action",
    "coerce_reset_body",
]

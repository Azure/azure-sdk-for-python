# pylint: disable=line-too-long,useless-suppression
# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
"""Customize generated code here.

Follow our quickstart for examples: https://aka.ms/azsdk/python/dpcodegen/python/customize
"""

import sys
from typing import Any, List
from ._patch_agents_async import AgentsOperations, BetaAgentsOperations
from ._patch_agent_insights_async import BetaAgentInsightMonitorsOperations
from ._patch_datasets_async import BetaDatasetsOperations, DatasetsOperations
from ._patch_evaluators_async import BetaEvaluatorsOperations
from ._patch_evaluation_rules_async import EvaluationRulesOperations
from ._patch_telemetry_async import TelemetryOperations
from ._patch_connections_async import ConnectionsOperations
from ._patch_memories_async import BetaMemoryStoresOperations
from ._patch_models_async import BetaModelsOperations
from ._patch_rle_async import (
    AsyncOpenEnvClient,
    AsyncOpenEnvInstance,
    AsyncOpenEnvWebSocket,
    RLEOperations,
)
from ...operations._patch import _BETA_OPERATION_FEATURE_HEADERS, _OperationMethodHeaderProxy
from .._realtime import (
    AsyncBetaRealtime,
    AsyncBetaRealtimeConnection,
    AsyncBetaRealtimeConnectionManager,
    ClientEvent,
    ConversationItem,
    ServerEvent,
)
from ._operations import (
    BetaEvaluationTaxonomiesOperations,
    BetaInsightsOperations,
    BetaOperations as GeneratedBetaOperations,
    BetaRedTeamsOperations,
    BetaRoutinesOperations,
    BetaSchedulesOperations,
    BetaSkillsOperations,
    BetaVoiceAgentsConversationsOperations,
    BetaVoiceAgentsOperations as GeneratedBetaVoiceAgentsOperations,
    BetaVoiceAgentsTelephonyOperations,
)

_RLE_GENERATED_OPERATION_NAMES = (
    "RLEnvironmentsOperations",
    "RLEInstanceGroupsOperations",
    "RLEInstancesOperations",
    "RLEInstanceRuntimeOperations",
)


class BetaVoiceAgentsOperations(GeneratedBetaVoiceAgentsOperations):
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~azure.ai.projects.aio.AIProjectClient`'s :attr:`beta` attribute's
        :attr:`~azure.ai.projects.aio.operations.BetaOperations.voice_agents` attribute.
    """

    conversations: BetaVoiceAgentsConversationsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaVoiceAgentsConversationsOperations` operations"""
    telephony: BetaVoiceAgentsTelephonyOperations
    """:class:`~azure.ai.projects.aio.operations.BetaVoiceAgentsTelephonyOperations` operations"""
    realtime: AsyncBetaRealtime
    """:class:`~azure.ai.projects.aio.operations.AsyncBetaRealtime` operations"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # The generator does not emit realtime operations at all, since azure-core's HTTP
        # pipeline has no way to keep a WebSocket upgrade's resulting socket alive. Add our
        # hand-written client, which manages a real, long-lived connection, in its place.
        self.realtime = AsyncBetaRealtime(self)


class BetaOperations(GeneratedBetaOperations):
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~azure.ai.projects.aio.AIProjectClient`'s
        :attr:`beta` attribute.
    """

    agents: BetaAgentsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaAgentsOperations` operations"""
    agent_insight_monitors: BetaAgentInsightMonitorsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaAgentInsightMonitorsOperations` operations"""
    evaluation_taxonomies: BetaEvaluationTaxonomiesOperations
    """:class:`~azure.ai.projects.aio.operations.BetaEvaluationTaxonomiesOperations` operations"""
    evaluators: BetaEvaluatorsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaEvaluatorsOperations` operations"""
    insights: BetaInsightsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaInsightsOperations` operations"""
    memory_stores: BetaMemoryStoresOperations
    """:class:`~azure.ai.projects.aio.operations.BetaMemoryStoresOperations` operations"""
    models: BetaModelsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaModelsOperations` operations"""
    red_teams: BetaRedTeamsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaRedTeamsOperations` operations"""
    routines: BetaRoutinesOperations
    """:class:`~azure.ai.projects.aio.operations.BetaRoutinesOperations` operations"""
    schedules: BetaSchedulesOperations
    """:class:`~azure.ai.projects.aio.operations.BetaSchedulesOperations` operations"""
    skills: BetaSkillsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaSkillsOperations` operations"""
    datasets: BetaDatasetsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaDatasetsOperations` operations"""
    voice_agents: BetaVoiceAgentsOperations
    """:class:`~azure.ai.projects.aio.operations.BetaVoiceAgentsOperations` operations"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Replace with patched class that returns AsyncEvaluatorGenerationLROPoller
        self.evaluators = BetaEvaluatorsOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that returns AsyncAgentOptimizationLROPoller
        self.agents = BetaAgentsOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that includes begin_update_memories
        self.memory_stores = BetaMemoryStoresOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that includes create (3-step upload helper)
        self.models = BetaModelsOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that returns AsyncDatasetGenerationLROPoller
        self.datasets = BetaDatasetsOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that returns AsyncAgentInsightRunLROPoller
        self.agent_insight_monitors = BetaAgentInsightMonitorsOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        # Replace with patched class that wires up the hand-written realtime client
        self.voice_agents = BetaVoiceAgentsOperations(self._client, self._config, self._serialize, self._deserialize)

        for property_name, foundry_features_value in _BETA_OPERATION_FEATURE_HEADERS.items():
            setattr(
                self,
                property_name,
                _OperationMethodHeaderProxy(getattr(self, property_name), foundry_features_value),
            )


__all__: List[str] = [
    "AgentsOperations",
    "AsyncBetaRealtime",
    "AsyncBetaRealtimeConnection",
    "AsyncBetaRealtimeConnectionManager",
    "AsyncOpenEnvClient",
    "AsyncOpenEnvInstance",
    "AsyncOpenEnvWebSocket",
    "BetaAgentInsightMonitorsOperations",
    "BetaAgentsOperations",
    "BetaDatasetsOperations",
    "BetaEvaluationTaxonomiesOperations",
    "BetaEvaluatorsOperations",
    "BetaInsightsOperations",
    "BetaMemoryStoresOperations",
    "BetaModelsOperations",
    "BetaOperations",
    "BetaRedTeamsOperations",
    "BetaRoutinesOperations",
    "BetaSchedulesOperations",
    "BetaSkillsOperations",
    "BetaVoiceAgentsConversationsOperations",
    "BetaVoiceAgentsOperations",
    "BetaVoiceAgentsTelephonyOperations",
    "ClientEvent",
    "ConnectionsOperations",
    "ConversationItem",
    "DatasetsOperations",
    "EvaluationRulesOperations",
    "ServerEvent",
    "RLEOperations",
    "TelemetryOperations",
]  # Add all objects you want publicly available to users at this package level


def patch_sdk():
    """Do not remove from this file.

    `patch_sdk` is a last resort escape hatch that allows you to do customizations
    you can't accomplish using the techniques described in
    https://aka.ms/azsdk/python/dpcodegen/python/customize
    """
    operations_module = sys.modules[__package__]
    operations_module.__all__[:] = [
        name for name in operations_module.__all__ if name not in _RLE_GENERATED_OPERATION_NAMES
    ]
    for name in _RLE_GENERATED_OPERATION_NAMES:
        operations_module.__dict__.pop(name, None)

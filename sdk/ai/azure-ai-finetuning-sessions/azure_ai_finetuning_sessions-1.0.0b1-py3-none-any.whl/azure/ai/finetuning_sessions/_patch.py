# coding=utf-8
# --------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------
"""Handwritten convenience layer on top of the generated FineTuningSessionClient.

``FineTuningSession`` wraps a live session and exposes the hero-code API from
SPEC_FOUNDRY_AICLIENT.md:

    session = FineTuningSession(client, session_id="session_xxx")
    fb_result  = session.forward_backward(batch, loss_fn="cross_entropy")
    opt_result = session.optim_step(AdamParams(learning_rate=1e-4))
    ckpt_result    = session.save_weights("my_checkpoint")
    sampler_result = session.save_weights_for_sampler(seq_id=0)
    sample_result  = session.sample(prompt_tokens, sampling_params, num_samples=4)
    session.close()

Each mutating method follows loom's two-step protocol:
  1. POST to the action endpoint — loom returns **200** with
     ``{request_id, session_id, status: "pending"}``.
  2. GET ``/fine_tuning/sessions/{sessionId}/request/{requestId}`` — the server
     long-polls (up to 5 minutes) and returns the typed result when the GPU finishes.

Note: the generated ``begin_*`` methods on sub-clients use the Azure LRO (202 +
Operation-Location header) pattern and will **not** work against loom, which returns
200.  Always use ``FineTuningSession`` methods for training operations.
"""
from __future__ import annotations

import json as _json
import time as _time
from typing import TYPE_CHECKING, Any, List, Optional, Union

from azure.core.rest import HttpRequest as _HttpRequest

from .models import (
    AdamParams,
    CreateSessionRequest,
    Datum,
    ForwardBackwardInput,
    ForwardBackwardRequest,
    LoRAConfig,
    LossFn,
    LossFnConfig,
    ModelInput,
    ModelInputChunk,
    OperationResult,
    OptimStepRequest,
    SampleRequest,
    SamplingParams,
    SaveCheckpointRequest,
    SaveSamplerWeightsRequest,
    FoundryFeaturesOptInKeys,
)
from ._utils.model_base import SdkJSONEncoder as _SdkJSONEncoder, _deserialize as _deserialize_model

# ── Loom wire-format → OperationResult discriminator map ─────────────────────
# Maps the last path segment of a Loom action URL to the SDK's "type" value.
_LOOM_SUBPATH_TO_OP_TYPE: dict[str, str] = {
    "forward_backward": "forward_backward",
    "optim_step": "optim_step",
    "checkpoint": "save_checkpoint",
    "checkpoint_sample": "save_sampler_weights",
    "sample": "sample",
}


def _normalize_loom_result(data: dict, op_type: str, request_id: str) -> dict:
    """Normalize the Loom poll-endpoint wire format into an OperationResult dict.

    The Loom server returns raw engine results (no ``"type"`` discriminator, metrics
    under namespaced keys like ``"total_loss:sum"``).  This function injects the
    discriminator and promotes metric fields so ``_deserialize(OperationResult, ...)``
    returns the correct typed subclass.
    """
    out = dict(data)
    out.setdefault("type", op_type)
    out.setdefault("operation_id", request_id)
    out.setdefault("status", "succeeded")

    metrics: dict = out.get("metrics") or {}

    if op_type == "forward_backward":
        if "total_loss" not in out:
            out["total_loss"] = float(metrics.get("total_loss:sum", 0.0))

    elif op_type == "optim_step":
        if "grad_norm" not in out:
            out["grad_norm"] = float(metrics.get("skyrl.ai/grad_norm", 0.0))
        if "step_count" not in out:
            out["step_count"] = int(metrics.get("step_count", 0))

    elif op_type == "save_sampler_weights":
        # Server may return "type": "save_weights_for_sampler" — normalise to SDK value.
        out["type"] = "save_sampler_weights"
        out.setdefault("checkpoint_id", out.get("checkpoint_id", ""))
        out.setdefault("sampling_session_id", out.get("sampling_session_id", ""))

    elif op_type == "save_checkpoint":
        out.setdefault("checkpoint_id", out.get("checkpoint_id", ""))
        out.setdefault("path", out.get("path", ""))

    return out

if TYPE_CHECKING:
    from ._client import FineTuningSessionClient

_PREVIEW = FoundryFeaturesOptInKeys.FINETUNING_SESSIONS_V1_PREVIEW
_API_VERSION = "v1"


class FineTuningSession:
    """Convenience wrapper around a single fine-tuning session.

    Mirrors the hero-code surface from SPEC_FOUNDRY_AICLIENT.md so callers
    can write training loops without constructing raw request bodies.

    :param client: The generated ``FineTuningSessionClient``.
    :param session_id: The session ID returned by the server after creating a session.
    """

    def __init__(self, client: "FineTuningSessionClient", session_id: str) -> None:
        self._client = client
        self.session_id = session_id

    # ── Factory ───────────────────────────────────────────────────────────────

    @classmethod
    def create(
        cls,
        client: "FineTuningSessionClient",
        *,
        base_model: str,
        lora_config: Optional[LoRAConfig] = None,
        type: str = "training",
        poll_interval_sec: float = 5.0,
        timeout_sec: float = 600.0,
    ) -> "FineTuningSession":
        """Create a fine-tuning session and wait until the model is loaded.

        Combines ``POST /fine_tuning/sessions`` (which triggers an async model-load
        on the server) with polling of the returned ``request_id`` until the load
        completes, then returns a ready-to-use :class:`FineTuningSession`.

        :param client: The :class:`~azure.ai.finetuning_sessions.FineTuningSessionClient`.
        :param base_model: Name of the base model to load (e.g. ``"Llama-3.1-8B"``).
        :param lora_config: Optional LoRA adapter config. Server default is used if omitted.
        :param type: Session type string. Defaults to ``"training"``.
        :param poll_interval_sec: Seconds between poll attempts. Defaults to ``5.0``.
        :param timeout_sec: Maximum seconds to wait for the model to load. Defaults to ``600.0``.
        :raises RuntimeError: If the server reports status ``"failed"`` or the timeout expires.
        :return: A :class:`FineTuningSession` instance ready for training operations.
        """
        body_json = _json.dumps(
            CreateSessionRequest(type=type, base_model=base_model, lora_config=lora_config),
            cls=_SdkJSONEncoder,
            exclude_readonly=True,
        )
        post_req = _HttpRequest(
            "POST",
            "{endpoint}/fine_tuning/sessions",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Foundry-Features": _PREVIEW.value,
            },
            params={"api-version": _API_VERSION},
            content=body_json,
        )
        post_resp = client.send_request(post_req)
        post_resp.raise_for_status()
        data = post_resp.json()
        raw_session_id: str = data["session_id"]
        request_id: str = data["request_id"]

        # The loom server stores the model record as f"model_{session_id}" (see
        # loom_create_model in the SQL/Cosmos providers).  Every route handler that
        # performs a training operation calls loom_require_model(provider, <url param>)
        # which does loom_get_model(<url param>).  Using the "model_" prefixed form as
        # our session_id means the URL path parameter matches the stored model_id, so
        # the lookup succeeds — no changes required on the server or engine side.
        session_id: str = f"model_{raw_session_id}"

        # Poll until the model-load request completes
        deadline = _time.monotonic() + timeout_sec
        while True:
            result = client.operations.get(
                session_id=session_id,
                operation_id=request_id,
                foundry_features=_PREVIEW,
                api_version=_API_VERSION,
            )
            status = result.status if result.status is not None else (result.get("status") if hasattr(result, "get") else None)
            if status == "succeeded":
                break
            if status == "failed":
                raise RuntimeError(f"Session model-load failed for session_id={raw_session_id}")
            if _time.monotonic() > deadline:
                raise RuntimeError(
                    f"Timed out after {timeout_sec}s waiting for session_id={raw_session_id} to become ready"
                )
            _time.sleep(poll_interval_sec)

        return cls(client, session_id=session_id)

    # ── Low-level helper ──────────────────────────────────────────────────────

    def _post_and_poll(self, subpath: str, body_model: Any) -> OperationResult:
        """POST to a loom action endpoint (returns 200 + request_id), then
        long-poll GET /request/{request_id} until the GPU finishes.

        Loom returns 200 (not 202) with ``{request_id, session_id, status}``
        from all mutating operations.  The poll endpoint blocks server-side
        (up to 5 minutes) and returns the typed result directly.
        """
        body_json = _json.dumps(body_model, cls=_SdkJSONEncoder, exclude_readonly=True)
        post_req = _HttpRequest(
            "POST",
            "{endpoint}" + subpath,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "Foundry-Features": _PREVIEW.value,
            },
            params={"api-version": _API_VERSION},
            content=body_json,
        )
        post_resp = self._client.send_request(post_req)
        post_resp.raise_for_status()
        data = post_resp.json()
        request_id = data["request_id"]
        session_id = data.get("session_id", self.session_id)

        # Long-poll the result directly so we can normalize the Loom wire format
        # before deserializing.  The generated operations.get() passes the raw JSON
        # straight to _deserialize(OperationResult, ...) which expects a "type"
        # discriminator field — but the Loom server returns its own engine format
        # (no "type", metrics under namespaced keys).  We do the GET ourselves,
        # normalize, then deserialize.
        op_type = _LOOM_SUBPATH_TO_OP_TYPE.get(subpath.rsplit("/", 1)[-1], "")
        poll_req = _HttpRequest(
            "GET",
            "{endpoint}" + f"/fine_tuning/sessions/{session_id}/request/{request_id}",
            headers={
                "Accept": "application/json",
                "Foundry-Features": _PREVIEW.value,
            },
            params={"api-version": _API_VERSION},
        )
        poll_resp = self._client.send_request(poll_req)
        poll_resp.raise_for_status()
        raw = poll_resp.json()
        normalized = _normalize_loom_result(raw, op_type, request_id)
        return _deserialize_model(OperationResult, normalized)

    # ── Training ──────────────────────────────────────────────────────────────

    def forward_backward(
        self,
        batch: List[Datum],
        *,
        loss_fn: Union[str, LossFn] = LossFn.CROSS_ENTROPY,
        loss_fn_config: Optional[LossFnConfig] = None,
        **kwargs: Any,
    ) -> OperationResult:
        """Submit a mini-batch for a forward + backward pass.

        Blocks until the GPU finishes the backward pass.

        Spec: ``fb_result = session.forward_backward(batch, loss_fn="cross_entropy")``

        :param batch: List of :class:`~azure.ai.finetuning_sessions.models.Datum`.
        :param loss_fn: Loss function name. Defaults to ``"cross_entropy"``.
        :param loss_fn_config: Optional per-loss hyper-parameters.
        :return: :class:`~azure.ai.finetuning_sessions.models.OperationResult`.
        """
        return self._post_and_poll(
            f"/fine_tuning/sessions/{self.session_id}/forward_backward",
            ForwardBackwardRequest(
                forward_backward_input=ForwardBackwardInput(
                    data=batch,
                    loss_fn=loss_fn,
                    loss_fn_config=loss_fn_config,
                )
            ),
        )

    def optim_step(
        self,
        adam_params: AdamParams,
        **kwargs: Any,
    ) -> OperationResult:
        """Apply accumulated gradients with Adam.

        Blocks until the GPU applies the weight update.

        Spec: ``opt_result = session.optim_step(AdamParams(learning_rate=1e-4))``
        """
        return self._post_and_poll(
            f"/fine_tuning/sessions/{self.session_id}/optim_step",
            OptimStepRequest(adam_params=adam_params),
        )

    # ── Checkpoints ───────────────────────────────────────────────────────────

    def save_weights(
        self,
        path: str,
        **kwargs: Any,
    ) -> OperationResult:
        """Save a training checkpoint (LoRA weights + optimizer state).

        Blocks until the checkpoint is written to storage.

        Spec: ``ckpt_result = session.save_weights("sft_piglatin_v1")``
        """
        return self._post_and_poll(
            f"/fine_tuning/sessions/{self.session_id}/checkpoint",
            SaveCheckpointRequest(path=path),
        )

    def save_weights_for_sampler(
        self,
        seq_id: int,
        *,
        sampling_session_seq_id: Optional[int] = None,
        path: Optional[str] = None,
        **kwargs: Any,
    ) -> OperationResult:
        """Push current LoRA weights to the sampler (required before calling ``sample``).

        Blocks until the sampler weights are ready.

        Spec: ``sampler_result = session.save_weights_for_sampler(seq_id=step)``

        :param seq_id: Training step index -- must match the ``seq_id`` passed to ``sample``.
        :param sampling_session_seq_id: Ordinal of this sampling session in the run.
        :param path: Optional explicit checkpoint identifier.
        """
        return self._post_and_poll(
            f"/fine_tuning/sessions/{self.session_id}/checkpoint_sample",
            SaveSamplerWeightsRequest(
                seq_id=seq_id,
                sampling_session_seq_id=sampling_session_seq_id,
                path=path,
            ),
        )

    # ── Sampling ──────────────────────────────────────────────────────────────

    def sample(
        self,
        prompt_tokens: List[int],
        sampling_params: SamplingParams,
        *,
        num_samples: int = 1,
        sampling_session_id: Optional[str] = None,
        seq_id: Optional[int] = None,
        prompt_logprobs: bool = False,
        topk_prompt_logprobs: int = 0,
        **kwargs: Any,
    ) -> OperationResult:
        """Generate completions using current LoRA weights.

        Blocks until the GPU finishes sampling.

        Spec: ``sample_result = session.sample(prompt_tokens, sampling_params, num_samples=4, ...)``

        :param prompt_tokens: Tokenised input prompt as a list of integer IDs.
        :param sampling_params: Generation parameters (max_tokens, temperature, etc.).
        :param num_samples: Number of independent completions to generate. Default 1.
        :param sampling_session_id: ID returned by a prior ``save_weights_for_sampler`` call.
        :param seq_id: Training step index; must match the one used in ``save_weights_for_sampler``.
        :param prompt_logprobs: If True, return per-token log-probabilities for the prompt.
        :param topk_prompt_logprobs: Top-k log-probabilities per prompt token. 0 = none.
        """
        return self._post_and_poll(
            f"/fine_tuning/sessions/{self.session_id}/sample",
            SampleRequest(
                num_samples=num_samples,
                prompt=ModelInput(chunks=[ModelInputChunk(tokens=prompt_tokens)]),
                sampling_params=sampling_params,
                topk_prompt_logprobs=topk_prompt_logprobs,
                sampling_session_id=sampling_session_id,
                seq_id=seq_id,
                prompt_logprobs=prompt_logprobs,
            ),
        )

    # ── Session lifecycle ─────────────────────────────────────────────────────

    def heartbeat(self, **kwargs: Any) -> Any:
        """Refresh an active session to prevent idle expiry."""
        return self._client.sessions.heartbeat(
            session_id=self.session_id,
            foundry_features=_PREVIEW,
            api_version=_API_VERSION,
            **kwargs,
        )

    def close(self, **kwargs: Any) -> None:
        """Unload the session from the GPU engine.

        Fire-and-forget: issues the complete request and returns immediately.

        Spec: ``session.close()``
        """
        close_req = _HttpRequest(
            "POST",
            "{endpoint}" + f"/fine_tuning/sessions/{self.session_id}/complete",
            headers={
                "Accept": "application/json",
                "Foundry-Features": _PREVIEW.value,
            },
            params={"api-version": _API_VERSION},
        )
        resp = self._client.send_request(close_req)
        resp.raise_for_status()


__all__: list[str] = ["FineTuningSession"]


def patch_sdk():
    """Do not remove from this file.

    `patch_sdk` is a last resort escape hatch that allows you to do customizations
    you can't accomplish using the techniques described in
    https://aka.ms/azsdk/python/dpcodegen/python/customize
    """
